package javaapplication6;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

final class DatabaseManager {
    private final Path databasePath;
    private boolean driverReady;

    DatabaseManager() throws SQLException {
        this.databasePath = locateDatabase();
        initializeSchema();
    }

    Path databasePath() {
        return databasePath;
    }

    UserAccount authenticate(String username, String password) throws SQLException {
        String sql = "SELECT UserId, Username, Password, UserType, Email FROM User "
                + "WHERE Username = ? AND Password = ?";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                return readUser(rs);
            }
        }
    }

    List<Movie> searchMovies(String keyword, String genre, String director, String year,
            boolean includeRestricted) throws SQLException {
        StringBuilder sql = new StringBuilder();
        String viewName = includeRestricted ? "vw_movie_details" : "vw_child_available_movies";
        sql.append("SELECT v.MovieID, v.Title, v.ReleaseYear, v.Language, v.CountryOfOrigin, v.Genre, ");
        sql.append("m.DirectorId, v.DirectorName, m.WatchedOrNot, ");
        sql.append("m.LeadingActorId, v.LeadingActorName, m.SupportingActorId, v.SupportingActorName, ");
        sql.append("v.About, v.MovieRating AS Rating, v.MovieComments AS Comments, v.Poster, m.ParentalRestriction ");
        sql.append("FROM ").append(viewName).append(" v ");
        sql.append("JOIN Movie m ON m.MovieID = v.MovieID ");
        sql.append("WHERE 1 = 1 ");
        List<Object> params = new ArrayList<>();
        if (!isBlank(keyword)) {
            sql.append("AND (LOWER(v.Title) LIKE ? OR LOWER(COALESCE(v.About, '')) LIKE ? ");
            sql.append("OR LOWER(COALESCE(v.Genre, '')) LIKE ?) ");
            String like = "%" + keyword.trim().toLowerCase() + "%";
            params.add(like);
            params.add(like);
            params.add(like);
        }
        if (!isBlank(genre) && !"(all genres)".equals(genre)) {
            sql.append("AND v.Genre = ? ");
            params.add(genre);
        }
        if (!isBlank(director) && !"(all directors)".equals(director)) {
            sql.append("AND v.DirectorName = ? ");
            params.add(director);
        }
        if (!isBlank(year)) {
            sql.append("AND SUBSTR(COALESCE(v.ReleaseYear, ''), 1, 4) = ? ");
            params.add(year.trim());
        }
        sql.append("ORDER BY v.Title");

        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                List<Movie> movies = new ArrayList<>();
                while (rs.next()) {
                    movies.add(readMovie(rs));
                }
                return movies;
            }
        }
    }

    List<String> listGenres(boolean includeRestricted) throws SQLException {
        String viewName = includeRestricted ? "vw_movie_details" : "vw_child_available_movies";
        String sql = "SELECT DISTINCT Genre FROM " + viewName + " ORDER BY Genre";
        List<String> genres = new ArrayList<>();
        genres.add("(all genres)");
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                if (!isBlank(rs.getString(1))) {
                    genres.add(rs.getString(1));
                }
            }
        }
        return genres;
    }

    List<String> listDirectors(boolean includeRestricted) throws SQLException {
        String viewName = includeRestricted ? "vw_movie_details" : "vw_child_available_movies";
        String sql = "SELECT DISTINCT DirectorName FROM " + viewName + " ORDER BY DirectorName";
        List<String> directors = new ArrayList<>();
        directors.add("(all directors)");
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                if (!isBlank(rs.getString(1))) {
                    directors.add(rs.getString(1));
                }
            }
        }
        return directors;
    }

    List<PersonItem> listPeople() throws SQLException {
        String sql = "SELECT PersonID, FirstName, LastName, DateOfBirth, Nationality FROM Person ORDER BY FirstName, LastName";
        List<PersonItem> people = new ArrayList<>();
        people.add(new PersonItem(0, "", "", "", ""));
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                people.add(new PersonItem(
                        rs.getInt("PersonID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("DateOfBirth"),
                        rs.getString("Nationality")
                ));
            }
        }
        return people;
    }

    int findOrCreatePersonId(String fullName) throws SQLException {
        String cleaned = normalizePersonName(fullName);
        if (isBlank(cleaned)) {
            return 0;
        }
        String sql = "SELECT PersonID FROM Person WHERE LOWER(TRIM(FirstName || ' ' || LastName)) = LOWER(?) LIMIT 1";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cleaned);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("PersonID");
                }
            }
        }

        String[] nameParts = splitPersonName(cleaned);
        String insert = "INSERT INTO Person (FirstName, LastName, DateOfBirth, Nationality) VALUES (?, ?, NULL, NULL)";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, nameParts[0]);
            ps.setString(2, nameParts[1]);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    int addMovie(Movie movie) throws SQLException {
        String sql = "INSERT INTO Movie (Title, ReleaseYear, Language, CountryOfOrigin, Genre, DirectorId, "
                + "WatchedOrNot, LeadingActorId, SupportingActorId, About, Rating, Comments, Poster, ParentalRestriction) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bindMovie(ps, movie);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    void updateMovie(Movie movie) throws SQLException {
        String sql = "UPDATE Movie SET Title = ?, ReleaseYear = ?, Language = ?, CountryOfOrigin = ?, Genre = ?, "
                + "DirectorId = ?, WatchedOrNot = ?, LeadingActorId = ?, SupportingActorId = ?, About = ?, "
                + "Rating = ?, Comments = ?, Poster = ?, ParentalRestriction = ? WHERE MovieID = ?";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            bindMovie(ps, movie);
            ps.setInt(15, movie.id);
            ps.executeUpdate();
        }
    }

    void deleteMovie(int movieId) throws SQLException {
        try (Connection conn = connect()) {
            conn.setAutoCommit(false);
            try (PreparedStatement a = conn.prepareStatement("DELETE FROM UserMovieActivity WHERE MovieID = ?");
                    PreparedStatement w = conn.prepareStatement("DELETE FROM Watchlist WHERE MovieID = ?");
                    PreparedStatement m = conn.prepareStatement("DELETE FROM Movie WHERE MovieID = ?")) {
                a.setInt(1, movieId);
                a.executeUpdate();
                w.setInt(1, movieId);
                w.executeUpdate();
                m.setInt(1, movieId);
                m.executeUpdate();
                conn.commit();
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        }
    }

    List<UserAccount> listUsers() throws SQLException {
        String sql = "SELECT UserId, Username, Password, UserType, Email FROM User ORDER BY UserType, Username";
        List<UserAccount> users = new ArrayList<>();
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                users.add(readUser(rs));
            }
        }
        return users;
    }

    int saveUser(UserAccount user) throws SQLException {
        if (user.id == 0) {
            String sql = "INSERT INTO User (Username, Password, UserType, Email) VALUES (?, ?, ?, ?)";
            try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, user.username);
                ps.setString(2, user.password);
                ps.setInt(3, user.userType);
                ps.setString(4, user.email);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    return rs.next() ? rs.getInt(1) : 0;
                }
            }
        }
        String sql = "UPDATE User SET Username = ?, Password = ?, UserType = ?, Email = ? WHERE UserId = ?";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.username);
            ps.setString(2, user.password);
            ps.setInt(3, user.userType);
            ps.setString(4, user.email);
            ps.setInt(5, user.id);
            ps.executeUpdate();
        }
        return user.id;
    }

    void deleteUser(int userId) throws SQLException {
        try (Connection conn = connect()) {
            conn.setAutoCommit(false);
            try (PreparedStatement a = conn.prepareStatement("DELETE FROM UserMovieActivity WHERE UserId = ?");
                    PreparedStatement w = conn.prepareStatement("DELETE FROM Watchlist WHERE UserId = ?");
                    PreparedStatement u = conn.prepareStatement("DELETE FROM User WHERE UserId = ?")) {
                a.setInt(1, userId);
                a.executeUpdate();
                w.setInt(1, userId);
                w.executeUpdate();
                u.setInt(1, userId);
                u.executeUpdate();
                conn.commit();
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        }
    }

    ActivityRecord activityForUserMovie(int userId, int movieId) throws SQLException {
        String sql = "SELECT ActivityId, UserId, MovieID, Watched, Rating, Comment, ActivityDate, CommentApproved "
                + "FROM UserMovieActivity WHERE UserId = ? AND MovieID = ?";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, movieId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                ActivityRecord record = new ActivityRecord();
                record.activityId = rs.getInt("ActivityId");
                record.userId = rs.getInt("UserId");
                record.movieId = rs.getInt("MovieID");
                record.watched = rs.getInt("Watched") == 1;
                record.rating = nullableInt(rs, "Rating");
                record.comment = rs.getString("Comment");
                record.date = rs.getString("ActivityDate");
                record.commentApproved = rs.getInt("CommentApproved") == 1;
                return record;
            }
        }
    }

    void saveActivity(int userId, int movieId, boolean watched, Integer rating, String comment) throws SQLException {
        ActivityRecord existing = activityForUserMovie(userId, movieId);
        int commentApproved = approvalValueForActivitySave(userId, comment, existing);
        if (existing == null) {
            String sql = "INSERT INTO UserMovieActivity (UserId, MovieID, Watched, Rating, Comment, ActivityDate, CommentApproved) "
                    + "VALUES (?, ?, ?, ?, ?, date('now'), ?)";
            try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, userId);
                ps.setInt(2, movieId);
                ps.setInt(3, watched ? 1 : 0);
                setNullableInt(ps, 4, rating);
                ps.setString(5, comment);
                ps.setInt(6, commentApproved);
                ps.executeUpdate();
            }
        } else {
            String sql = "UPDATE UserMovieActivity SET Watched = ?, Rating = ?, Comment = ?, "
                    + "ActivityDate = date('now'), CommentApproved = ? "
                    + "WHERE UserId = ? AND MovieID = ?";
            try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, watched ? 1 : 0);
                setNullableInt(ps, 2, rating);
                ps.setString(3, comment);
                ps.setInt(4, commentApproved);
                ps.setInt(5, userId);
                ps.setInt(6, movieId);
                ps.executeUpdate();
            }
        }
        refreshMovieWatchedFlag(movieId);
    }

    void addToWatchlist(int userId, int movieId) throws SQLException {
        String sql = "INSERT OR IGNORE INTO Watchlist (UserId, MovieID, AddedDate) VALUES (?, ?, date('now'))";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, movieId);
            ps.executeUpdate();
        }
    }

    void removeFromWatchlist(int userId, int movieId) throws SQLException {
        String sql = "DELETE FROM Watchlist WHERE UserId = ? AND MovieID = ?";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, movieId);
            ps.executeUpdate();
        }
    }

    List<WatchlistRecord> watchlistForUser(int userId) throws SQLException {
        return watchlistForUser(userId, false);
    }

    List<WatchlistRecord> watchlistForUser(int userId, boolean includeRestricted) throws SQLException {
        String sql = "SELECT WatchlistId, MovieID, Title, Genre, AddedDate "
                + "FROM vw_watchlist_details "
                + "WHERE UserId = ? "
                + (includeRestricted ? "" : "AND COALESCE(ParentalRestriction, 0) = 0 ")
                + "ORDER BY AddedDate DESC, Title";
        List<WatchlistRecord> rows = new ArrayList<>();
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    WatchlistRecord record = new WatchlistRecord();
                    record.watchlistId = rs.getInt("WatchlistId");
                    record.movieId = rs.getInt("MovieID");
                    record.title = rs.getString("Title");
                    record.genre = rs.getString("Genre");
                    record.addedDate = rs.getString("AddedDate");
                    rows.add(record);
                }
            }
        }
        return rows;
    }

    List<PersonalMovieRecord> watchedMoviesForUser(int userId) throws SQLException {
        return watchedMoviesForUser(userId, false);
    }

    List<PersonalMovieRecord> watchedMoviesForUser(int userId, boolean includeRestricted) throws SQLException {
        String sql = "SELECT a.MovieID, m.Title, m.Genre, a.Rating, a.ActivityDate "
                + "FROM UserMovieActivity a "
                + "JOIN Movie m ON m.MovieID = a.MovieID "
                + "WHERE a.UserId = ? AND a.Watched = 1 "
                + (includeRestricted ? "" : "AND COALESCE(m.ParentalRestriction, 0) = 0 ")
                + "ORDER BY a.ActivityDate DESC, m.Title";
        List<PersonalMovieRecord> rows = new ArrayList<>();
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    PersonalMovieRecord record = new PersonalMovieRecord();
                    record.movieId = rs.getInt("MovieID");
                    record.title = rs.getString("Title");
                    record.genre = rs.getString("Genre");
                    record.rating = nullableInt(rs, "Rating");
                    record.date = rs.getString("ActivityDate");
                    rows.add(record);
                }
            }
        }
        return rows;
    }

    boolean isInWatchlist(int userId, int movieId) throws SQLException {
        String sql = "SELECT 1 FROM Watchlist WHERE UserId = ? AND MovieID = ? LIMIT 1";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, movieId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    void setWatchedForUserMovie(int userId, int movieId, boolean watched) throws SQLException {
        ActivityRecord existing = activityForUserMovie(userId, movieId);
        if (existing == null) {
            String sql = "INSERT INTO UserMovieActivity (UserId, MovieID, Watched, ActivityDate, CommentApproved) "
                    + "VALUES (?, ?, ?, date('now'), 1)";
            try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, userId);
                ps.setInt(2, movieId);
                ps.setInt(3, watched ? 1 : 0);
                ps.executeUpdate();
            }
        } else {
            String sql = "UPDATE UserMovieActivity SET Watched = ?, ActivityDate = date('now') "
                    + "WHERE UserId = ? AND MovieID = ?";
            try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, watched ? 1 : 0);
                ps.setInt(2, userId);
                ps.setInt(3, movieId);
                ps.executeUpdate();
            }
        }
        refreshMovieWatchedFlag(movieId);
    }

    List<RatingRecord> ratingsForMovie(int movieId, int viewerUserId, boolean viewerIsParent) throws SQLException {
        String sql = "SELECT UserId, Username, UserType, Watched, Rating, Comment, ActivityDate, CommentApproved "
                + "FROM vw_family_ratings WHERE MovieID = ? ORDER BY Username";
        List<RatingRecord> rows = new ArrayList<>();
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, movieId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    RatingRecord record = new RatingRecord();
                    record.userId = rs.getInt("UserId");
                    record.username = rs.getString("Username");
                    int userType = rs.getInt("UserType");
                    record.role = userType == 1 ? "Parent" : "Child";
                    record.watched = rs.getInt("Watched") == 1;
                    record.rating = nullableInt(rs, "Rating");
                    record.comment = visibleComment(
                            rs.getString("Comment"),
                            rs.getInt("CommentApproved") == 1,
                            record.userId,
                            viewerUserId,
                            viewerIsParent,
                            userType
                    );
                    record.date = rs.getString("ActivityDate");
                    record.commentApproved = rs.getInt("CommentApproved") == 1 || userType == 1;
                    rows.add(record);
                }
            }
        }
        return rows;
    }

    List<FamilyCommentRecord> familyCommentsForViewer(int viewerUserId, boolean viewerIsParent,
            boolean includeRestricted) throws SQLException {
        String sql = "SELECT r.MovieID, r.Title, r.UserId, r.Username, r.UserType, r.Rating, "
                + "r.Comment, r.ActivityDate, r.CommentApproved, m.ParentalRestriction "
                + "FROM vw_family_ratings r "
                + "JOIN Movie m ON m.MovieID = r.MovieID "
                + "WHERE TRIM(COALESCE(r.Comment, '')) <> '' "
                + (includeRestricted ? "" : "AND COALESCE(m.ParentalRestriction, 0) = 0 ")
                + "AND (COALESCE(r.CommentApproved, 1) = 1 OR r.UserId = ? OR r.UserType = 1 "
                + (viewerIsParent ? "OR 1 = 1 " : "")
                + ") ORDER BY r.ActivityDate DESC, r.Title, r.Username";
        List<FamilyCommentRecord> rows = new ArrayList<>();
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, viewerUserId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int userType = rs.getInt("UserType");
                    FamilyCommentRecord record = new FamilyCommentRecord();
                    record.movieId = rs.getInt("MovieID");
                    record.movieTitle = rs.getString("Title");
                    record.username = rs.getString("Username");
                    record.role = userType == 1 ? "Parent" : "Child";
                    record.rating = nullableInt(rs, "Rating");
                    record.comment = rs.getString("Comment");
                    boolean publicComment = rs.getInt("CommentApproved") == 1 || userType == 1;
                    record.status = publicComment ? "Public" : "Pending approval";
                    record.date = rs.getString("ActivityDate");
                    rows.add(record);
                }
            }
        }
        return rows;
    }

    List<ActivityRecord> moderationRecords() throws SQLException {
        String sql = "SELECT ActivityId, UserId, MovieID, Username, Title, Watched, "
                + "Rating, Comment, ActivityDate, CommentApproved "
                + "FROM vw_comments_for_moderation "
                + "ORDER BY CommentApproved ASC, ActivityDate DESC, Username";
        List<ActivityRecord> rows = new ArrayList<>();
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                ActivityRecord record = new ActivityRecord();
                record.activityId = rs.getInt("ActivityId");
                record.userId = rs.getInt("UserId");
                record.movieId = rs.getInt("MovieID");
                record.username = rs.getString("Username");
                record.movieTitle = rs.getString("Title");
                record.watched = rs.getInt("Watched") == 1;
                record.rating = nullableInt(rs, "Rating");
                record.comment = rs.getString("Comment");
                record.date = rs.getString("ActivityDate");
                record.commentApproved = rs.getInt("CommentApproved") == 1;
                rows.add(record);
            }
        }
        return rows;
    }

    void approveActivityComment(int activityId) throws SQLException {
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(
                "UPDATE UserMovieActivity SET CommentApproved = 1 WHERE ActivityId = ?")) {
            ps.setInt(1, activityId);
            ps.executeUpdate();
        }
    }

    void clearActivityComment(int activityId) throws SQLException {
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(
                "UPDATE UserMovieActivity SET Comment = '', CommentApproved = 1 WHERE ActivityId = ?")) {
            ps.setInt(1, activityId);
            ps.executeUpdate();
        }
    }

    void deleteActivity(int activityId) throws SQLException {
        int movieId = 0;
        try (Connection conn = connect(); PreparedStatement read = conn.prepareStatement(
                "SELECT MovieID FROM UserMovieActivity WHERE ActivityId = ?")) {
            read.setInt(1, activityId);
            try (ResultSet rs = read.executeQuery()) {
                if (rs.next()) {
                    movieId = rs.getInt(1);
                }
            }
        }
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM UserMovieActivity WHERE ActivityId = ?")) {
            ps.setInt(1, activityId);
            ps.executeUpdate();
        }
        if (movieId != 0) {
            refreshMovieWatchedFlag(movieId);
        }
    }

    String analyticsText() throws SQLException {
        StringBuilder out = new StringBuilder();
        out.append("MovieCritics Family Analytics\n\n");
        out.append("Summary\n");
        out.append("Movies in library: ").append(count("Movie")).append("\n");
        out.append("Watched at least once: ").append(countWhere("Movie", "WatchedOrNot = 1")).append("\n");
        out.append("Parental restricted movies: ").append(countWhere("Movie", "COALESCE(ParentalRestriction, 0) = 1")).append("\n");
        out.append("Parents/adults: ").append(countWhere("User", "UserType = 1")).append("\n");
        out.append("Kids: ").append(countWhere("User", "UserType = 2")).append("\n");
        out.append("Watchlist items: ").append(count("Watchlist")).append("\n");
        out.append("Ratings/comments saved: ").append(count("UserMovieActivity")).append("\n");
        out.append("Pending kid comments: ").append(countWhere("UserMovieActivity",
                "COALESCE(CommentApproved, 1) = 0 AND TRIM(COALESCE(Comment, '')) <> ''")).append("\n\n");

        out.append("Most watched movies\n");
        appendQueryLines(out,
                "SELECT m.Title, COUNT(*) AS WatchedCount FROM UserMovieActivity a "
                + "JOIN Movie m ON m.MovieID = a.MovieID WHERE a.Watched = 1 "
                + "GROUP BY m.MovieID, m.Title ORDER BY WatchedCount DESC, m.Title LIMIT 5",
                "Title", "WatchedCount");

        out.append("\nHighest family ratings (1-5)\n");
        appendQueryLines(out,
                "SELECT m.Title, printf('%.2f', AVG(a.Rating)) AS AvgRating FROM UserMovieActivity a "
                + "JOIN Movie m ON m.MovieID = a.MovieID WHERE a.Rating IS NOT NULL "
                + "GROUP BY m.MovieID, m.Title ORDER BY AVG(a.Rating) DESC, m.Title LIMIT 5",
                "Title", "AvgRating");

        out.append("\nMost active family members\n");
        appendQueryLines(out,
                "SELECT u.Username, COUNT(a.ActivityId) AS ActivityCount FROM User u "
                + "LEFT JOIN UserMovieActivity a ON a.UserId = u.UserId "
                + "GROUP BY u.UserId, u.Username ORDER BY ActivityCount DESC, u.Username",
                "Username", "ActivityCount");

        out.append("\nGenre distribution\n");
        appendQueryLines(out,
                "SELECT COALESCE(Genre, 'Unknown') AS Genre, COUNT(*) AS MovieCount "
                + "FROM Movie GROUP BY COALESCE(Genre, 'Unknown') ORDER BY MovieCount DESC, Genre",
                "Genre", "MovieCount");

        out.append("\nKids progress\n");
        String progressSql = "SELECT u.Username, COUNT(a.MovieID) AS WatchedMovies "
                + "FROM User u LEFT JOIN UserMovieActivity a ON a.UserId = u.UserId AND a.Watched = 1 "
                + "WHERE u.UserType = 2 GROUP BY u.UserId, u.Username ORDER BY WatchedMovies DESC, u.Username";
        appendQueryLines(out, progressSql, "Username", "WatchedMovies");

        out.append("\nComments waiting for parent approval\n");
        appendQueryLines(out,
                "SELECT u.Username || ' on ' || m.Title AS Item, a.ActivityDate AS ActivityDate "
                + "FROM UserMovieActivity a JOIN User u ON u.UserId = a.UserId "
                + "JOIN Movie m ON m.MovieID = a.MovieID "
                + "WHERE COALESCE(a.CommentApproved, 1) = 0 AND TRIM(COALESCE(a.Comment, '')) <> '' "
                + "ORDER BY a.ActivityDate DESC",
                "Item", "ActivityDate");

        return out.toString();
    }

    AnalyticsSummary analyticsSummary() throws SQLException {
        AnalyticsSummary summary = new AnalyticsSummary();
        try (Connection conn = connect(); Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("SELECT * FROM vw_parent_dashboard")) {
            if (rs.next()) {
                summary.movieCount = rs.getInt("TotalMovies");
                summary.watchedMovieCount = rs.getInt("TotalWatchedRecords");
                summary.restrictedMovieCount = rs.getInt("RestrictedMovies");
                summary.parentCount = rs.getInt("ParentUserCount");
                summary.childCount = rs.getInt("ChildUserCount");
                summary.activityCount = rs.getInt("TotalWatchedRecords");
                summary.watchlistCount = rs.getInt("TotalWatchlistItems");
                summary.averageFamilyRating = rs.getString("OverallAverageFamilyRating");
            }
        }
        summary.pendingCommentCount = countWhere("UserMovieActivity",
                "COALESCE(CommentApproved, 1) = 0 AND TRIM(COALESCE(Comment, '')) <> ''");
        if (isBlank(summary.averageFamilyRating)) {
            summary.averageFamilyRating = "No ratings yet";
        } else {
            summary.averageFamilyRating = summary.averageFamilyRating + " / 5";
        }
        return summary;
    }

    List<Object[]> mostWatchedAnalyticsRows() throws SQLException {
        return queryRows(
                "SELECT w.Title AS Title, w.WatchedCount AS WatchedCount, "
                + "COALESCE(d.Genre, '-') AS Genre, COALESCE(d.ReleaseYear, '-') AS ReleaseDate "
                + "FROM vw_most_watched_movies w JOIN vw_movie_details d ON d.MovieID = w.MovieID "
                + "ORDER BY w.WatchedCount DESC, w.Title LIMIT 10",
                "Title", "WatchedCount", "Genre", "ReleaseDate"
        );
    }

    List<Object[]> averageRatingAnalyticsRows() throws SQLException {
        return queryRows(
                "SELECT a.Title AS Title, COALESCE(a.AverageRating, '-') AS AverageRating, "
                + "a.RatingCount AS RatingCount, "
                + "COALESCE(CASE WHEN m.Rating > 5 THEN ROUND(m.Rating / 2.0, 1) ELSE m.Rating END, '-') AS LibraryRating "
                + "FROM vw_movie_average_ratings a JOIN Movie m ON m.MovieID = a.MovieID "
                + "ORDER BY a.AverageRating DESC, a.RatingCount DESC, a.Title",
                "Title", "AverageRating", "RatingCount", "LibraryRating"
        );
    }

    List<Object[]> familyActivityAnalyticsRows() throws SQLException {
        return queryRows(
                "SELECT Username, UserRole AS Role, TotalActivityRecords AS ActivityCount, "
                + "WatchedMovieCount AS WatchedCount, COALESCE(AverageGivenRating, '-') AS AverageRating "
                + "FROM vw_user_progress "
                + "ORDER BY WatchedMovieCount DESC, TotalActivityRecords DESC, Username",
                "Username", "Role", "ActivityCount", "WatchedCount", "AverageRating"
        );
    }

    List<Object[]> childProgressAnalyticsRows() throws SQLException {
        return queryRows(
                "SELECT Child, WatchedMovies, VisibleMovies, "
                + "printf('%.0f%%', CASE WHEN VisibleMovies = 0 THEN 0 ELSE WatchedMovies * 100.0 / VisibleMovies END) AS Progress "
                + "FROM ("
                + "SELECT u.Username AS Child, "
                + "COALESCE(SUM(CASE WHEN a.Watched = 1 AND COALESCE(m.ParentalRestriction, 0) = 0 THEN 1 ELSE 0 END), 0) AS WatchedMovies, "
                + "(SELECT COUNT(*) FROM Movie WHERE COALESCE(ParentalRestriction, 0) = 0) AS VisibleMovies "
                + "FROM \"User\" u "
                + "LEFT JOIN UserMovieActivity a ON a.UserId = u.UserId "
                + "LEFT JOIN Movie m ON m.MovieID = a.MovieID "
                + "WHERE u.UserType = 2 "
                + "GROUP BY u.UserId, u.Username"
                + ") ORDER BY WatchedMovies DESC, Child",
                "Child", "WatchedMovies", "VisibleMovies", "Progress"
        );
    }

    List<Object[]> pendingCommentAnalyticsRows() throws SQLException {
        return queryRows(
                "SELECT Username AS Child, Title AS Movie, Comment AS Comment, ActivityDate AS Date "
                + "FROM vw_comments_for_moderation "
                + "WHERE COALESCE(CommentApproved, 1) = 0 AND TRIM(COALESCE(Comment, '')) <> '' "
                + "ORDER BY ActivityDate DESC, Username",
                "Child", "Movie", "Comment", "Date"
        );
    }

    String progressText(UserAccount user) throws SQLException {
        int visibleMovies = countWhere("Movie", "COALESCE(ParentalRestriction, 0) = 0");
        int watched = watchedCount(user.id);
        StringBuilder out = new StringBuilder();
        out.append(user.username).append("'s progress\n\n");
        out.append("Visible movies: ").append(visibleMovies).append("\n");
        out.append("Watched movies: ").append(watched).append("\n");
        out.append("Remaining movies: ").append(Math.max(0, visibleMovies - watched)).append("\n\n");
        out.append("Sibling comparison\n");
        String sql = "SELECT u.Username, COUNT(a.MovieID) AS WatchedMovies "
                + "FROM User u LEFT JOIN UserMovieActivity a ON a.UserId = u.UserId AND a.Watched = 1 "
                + "WHERE u.UserType = 2 GROUP BY u.UserId, u.Username ORDER BY WatchedMovies DESC, u.Username";
        appendQueryLines(out, sql, "Username", "WatchedMovies");
        return out.toString();
    }

    PersonalProgressSummary personalProgressSummary(UserAccount user) throws SQLException {
        PersonalProgressSummary summary = new PersonalProgressSummary();
        summary.visibleMovies = countWhere("Movie", "COALESCE(ParentalRestriction, 0) = 0");
        summary.watchedMovies = watchedCount(user.id);
        summary.remainingMovies = Math.max(0, summary.visibleMovies - summary.watchedMovies);
        summary.progressValue = summary.visibleMovies == 0
                ? 0
                : (int) Math.round(summary.watchedMovies * 100.0 / summary.visibleMovies);
        summary.progressPercent = summary.progressValue + "%";
        return summary;
    }

    private int watchedCount(int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM UserMovieActivity a JOIN Movie m ON m.MovieID = a.MovieID "
                + "WHERE a.UserId = ? AND a.Watched = 1 AND COALESCE(m.ParentalRestriction, 0) = 0";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    private void appendQueryLines(StringBuilder out, String sql, String labelColumn, String valueColumn) throws SQLException {
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            boolean any = false;
            while (rs.next()) {
                any = true;
                out.append(" - ")
                        .append(rs.getString(labelColumn))
                        .append(": ")
                        .append(rs.getString(valueColumn))
                        .append("\n");
            }
            if (!any) {
                out.append(" - No data yet\n");
            }
        }
    }

    private List<Object[]> queryRows(String sql, String... columns) throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Object[] row = new Object[columns.length];
                for (int i = 0; i < columns.length; i++) {
                    row[i] = rs.getObject(columns[i]);
                }
                rows.add(row);
            }
        }
        return rows;
    }

    private String scalarString(String sql) throws SQLException {
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getString(1) : "";
        }
    }

    private int count(String tableName) throws SQLException {
        return countWhere(tableName, null);
    }

    private int countWhere(String tableName, String where) throws SQLException {
        String sql = "SELECT COUNT(*) FROM " + tableName + (where == null ? "" : " WHERE " + where);
        try (Connection conn = connect(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private void refreshMovieWatchedFlag(int movieId) throws SQLException {
        String sql = "UPDATE Movie SET WatchedOrNot = (SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END "
                + "FROM UserMovieActivity WHERE MovieID = ? AND Watched = 1) WHERE MovieID = ?";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, movieId);
            ps.setInt(2, movieId);
            ps.executeUpdate();
        }
    }

    private int approvalValueForActivitySave(int userId, String comment, ActivityRecord existing) throws SQLException {
        if (isBlank(comment)) {
            return 1;
        }
        if (!isChildUser(userId)) {
            return 1;
        }
        if (existing != null && existing.commentApproved && safeString(existing.comment).equals(safeString(comment))) {
            return 1;
        }
        return 0;
    }

    private String visibleComment(String comment, boolean approved, int commentUserId, int viewerUserId,
            boolean viewerIsParent, int commentUserType) {
        if (isBlank(comment)) {
            return "";
        }
        if (approved || viewerIsParent || commentUserId == viewerUserId || commentUserType == 1) {
            return comment;
        }
        return "[comment waiting for parent approval]";
    }

    private boolean isChildUser(int userId) throws SQLException {
        String sql = "SELECT UserType FROM User WHERE UserId = ?";
        try (Connection conn = connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt("UserType") == 2;
            }
        }
    }

    private static String safeString(String text) {
        return text == null ? "" : text;
    }

    private void bindMovie(PreparedStatement ps, Movie movie) throws SQLException {
        ps.setString(1, value(movie.title));
        ps.setString(2, normalizeDate(movie.releaseDate));
        ps.setString(3, value(movie.language));
        ps.setString(4, value(movie.country));
        ps.setString(5, value(movie.genre));
        setNullableInt(ps, 6, movie.directorId == 0 ? null : movie.directorId);
        ps.setInt(7, movie.watchedOrNot ? 1 : 0);
        setNullableInt(ps, 8, movie.leadingActorId == 0 ? null : movie.leadingActorId);
        setNullableInt(ps, 9, movie.supportingActorId == 0 ? null : movie.supportingActorId);
        ps.setString(10, value(movie.about));
        setNullableInt(ps, 11, movie.rating);
        ps.setString(12, value(movie.comments));
        ps.setString(13, value(movie.poster));
        ps.setInt(14, movie.parentalRestriction ? 1 : 0);
    }

    private static String normalizeDate(String date) {
        if (isBlank(date)) {
            return null;
        }
        String trimmed = date.trim();
        if (trimmed.matches("\\d{4}")) {
            return trimmed + "-01-01";
        }
        return trimmed;
    }

    private static String value(String text) {
        return isBlank(text) ? null : text.trim();
    }

    private static Integer normalizeLibraryRating(Integer rating) {
        if (rating == null) {
            return null;
        }
        if (rating > 5) {
            return Math.max(1, Math.min(5, (int) Math.round(rating / 2.0)));
        }
        return Math.max(1, Math.min(5, rating));
    }

    private static String normalizePersonName(String fullName) {
        if (isBlank(fullName)) {
            return "";
        }
        return fullName.trim().replaceAll("\\s+", " ");
    }

    private static String[] splitPersonName(String fullName) {
        String cleaned = normalizePersonName(fullName);
        int lastSpace = cleaned.lastIndexOf(' ');
        if (lastSpace < 0) {
            return new String[]{cleaned, ""};
        }
        String firstName = cleaned.substring(0, lastSpace).trim();
        String lastName = cleaned.substring(lastSpace + 1).trim();
        if (firstName.isEmpty()) {
            firstName = lastName;
            lastName = "";
        }
        return new String[]{firstName, lastName};
    }

    private static void bind(PreparedStatement ps, List<Object> params) throws SQLException {
        for (int i = 0; i < params.size(); i++) {
            ps.setObject(i + 1, params.get(i));
        }
    }

    private static void setNullableInt(PreparedStatement ps, int index, Integer value) throws SQLException {
        if (value == null) {
            ps.setObject(index, null);
        } else {
            ps.setInt(index, value);
        }
    }

    private static Integer nullableInt(ResultSet rs, String column) throws SQLException {
        int value = rs.getInt(column);
        return rs.wasNull() ? null : value;
    }

    private static boolean isBlank(String text) {
        return text == null || text.trim().isEmpty();
    }

    private UserAccount readUser(ResultSet rs) throws SQLException {
        return new UserAccount(
                rs.getInt("UserId"),
                rs.getString("Username"),
                rs.getString("Password"),
                rs.getInt("UserType"),
                rs.getString("Email")
        );
    }

    private Movie readMovie(ResultSet rs) throws SQLException {
        Movie movie = new Movie();
        movie.id = rs.getInt("MovieID");
        movie.title = rs.getString("Title");
        movie.releaseDate = rs.getString("ReleaseYear");
        movie.language = rs.getString("Language");
        movie.country = rs.getString("CountryOfOrigin");
        movie.genre = rs.getString("Genre");
        movie.directorId = rs.getInt("DirectorId");
        if (rs.wasNull()) {
            movie.directorId = 0;
        }
        movie.directorName = rs.getString("DirectorName");
        movie.watchedOrNot = rs.getInt("WatchedOrNot") == 1;
        movie.leadingActorId = rs.getInt("LeadingActorId");
        if (rs.wasNull()) {
            movie.leadingActorId = 0;
        }
        movie.leadingActorName = rs.getString("LeadingActorName");
        movie.supportingActorId = rs.getInt("SupportingActorId");
        if (rs.wasNull()) {
            movie.supportingActorId = 0;
        }
        movie.supportingActorName = rs.getString("SupportingActorName");
        movie.about = rs.getString("About");
        movie.rating = normalizeLibraryRating(nullableInt(rs, "Rating"));
        movie.comments = rs.getString("Comments");
        movie.poster = rs.getString("Poster");
        movie.parentalRestriction = rs.getInt("ParentalRestriction") == 1;
        return movie;
    }

    private Connection connect() throws SQLException {
        ensureDriver();
        Connection conn = DriverManager.getConnection("jdbc:sqlite:" + databasePath.toAbsolutePath());
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
        }
        return conn;
    }

    private void ensureDriver() throws SQLException {
        if (driverReady) {
            return;
        }
        try {
            Class.forName("org.sqlite.JDBC");
            driverReady = true;
            return;
        } catch (ClassNotFoundException ignored) {
            // Try loading the jar dynamically below.
        }

        Path jar = locateSqliteJar();
        if (jar == null) {
            throw new SQLException("SQLite JDBC driver was not found. Put sqlite-jdbc-3.51.3.0.jar in a lib folder, "
                    + "or run with -Dsqlite.jar=C:\\path\\to\\sqlite-jdbc.jar");
        }
        try {
            URLClassLoader loader = new URLClassLoader(new URL[]{jar.toUri().toURL()}, DatabaseManager.class.getClassLoader());
            Class<?> driverClass = Class.forName("org.sqlite.JDBC", true, loader);
            Driver driver = (Driver) driverClass.getDeclaredConstructor().newInstance();
            DriverManager.registerDriver(new DriverShim(driver));
            driverReady = true;
        } catch (Exception ex) {
            throw new SQLException("Could not load SQLite JDBC driver from " + jar + ": " + ex.getMessage(), ex);
        }
    }

    private Path locateDatabase() {
        String configured = System.getProperty("moviecritics.db");
        if (!isBlank(configured)) {
            return Paths.get(configured);
        }
        List<Path> candidates = new ArrayList<>();
        Path cwd = Paths.get("").toAbsolutePath();
        Path codeBase = codeBaseDirectory();
        candidates.add(cwd.resolve("moviecritics.db"));
        candidates.add(cwd.resolve("src").resolve("javaapplication6").resolve("moviecritics.db"));
        candidates.add(cwd.getParent() == null ? cwd.resolve("moviecritics.db") : cwd.getParent().resolve("moviecritics.db"));
        if (codeBase != null) {
            candidates.add(codeBase.resolve("moviecritics.db"));
            candidates.add(codeBase.resolve("app").resolve("moviecritics.db"));
            if (codeBase.getParent() != null) {
                candidates.add(codeBase.getParent().resolve("moviecritics.db"));
                candidates.add(codeBase.getParent().resolve("app").resolve("moviecritics.db"));
            }
        }
        candidates.add(Paths.get(System.getProperty("user.home"), "Downloads", "moviecritics.db"));
        for (Path candidate : candidates) {
            if (Files.exists(candidate)) {
                return candidate;
            }
        }
        return cwd.resolve("moviecritics.db");
    }

    private Path locateSqliteJar() {
        String configured = System.getProperty("sqlite.jar");
        if (!isBlank(configured) && Files.exists(Paths.get(configured))) {
            return Paths.get(configured);
        }
        List<Path> candidates = new ArrayList<>();
        Path cwd = Paths.get("").toAbsolutePath();
        Path codeBase = codeBaseDirectory();
        candidates.add(cwd.resolve("lib").resolve("sqlite-jdbc-3.51.3.0.jar"));
        candidates.add(cwd.resolve("sqlite-jdbc-3.51.3.0.jar"));
        candidates.add(cwd.resolve("src").resolve("javaapplication6").resolve("sqlite-jdbc-3.51.3.0.jar"));
        if (codeBase != null) {
            candidates.add(codeBase.resolve("lib").resolve("sqlite-jdbc-3.51.3.0.jar"));
            candidates.add(codeBase.resolve("sqlite-jdbc-3.51.3.0.jar"));
            if (codeBase.getParent() != null) {
                candidates.add(codeBase.getParent().resolve("lib").resolve("sqlite-jdbc-3.51.3.0.jar"));
                candidates.add(codeBase.getParent().resolve("sqlite-jdbc-3.51.3.0.jar"));
            }
        }
        candidates.add(Paths.get(System.getProperty("user.home"), "Downloads", "sqlite-jdbc-3.51.3.0.jar"));
        candidates.add(Paths.get(System.getProperty("user.home"), "OneDrive", "Belgeler", "NetBeansProjects",
                "JavaApplication1", "lib", "sqlite-jdbc-3.51.3.0.jar"));
        for (Path candidate : candidates) {
            if (Files.exists(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private Path codeBaseDirectory() {
        try {
            File location = new File(DatabaseManager.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            if (location.isFile()) {
                return location.toPath().getParent();
            }
            return location.toPath();
        } catch (Exception ex) {
            return null;
        }
    }

    private void initializeSchema() throws SQLException {
        try (Connection conn = connect(); Statement st = conn.createStatement()) {
            st.execute("""
                    CREATE TABLE IF NOT EXISTS Person (
                        PersonID INTEGER PRIMARY KEY AUTOINCREMENT,
                        FirstName VARCHAR(100) NOT NULL,
                        LastName VARCHAR(100) NOT NULL,
                        DateOfBirth DATE,
                        Nationality VARCHAR(100)
                    )
                    """);
            st.execute("""
                    CREATE TABLE IF NOT EXISTS User (
                        UserId INTEGER PRIMARY KEY AUTOINCREMENT,
                        Username VARCHAR(100) NOT NULL UNIQUE,
                        Password VARCHAR(100) NOT NULL,
                        UserType INTEGER NOT NULL,
                        Email VARCHAR(255)
                    )
                    """);
            st.execute("""
                    CREATE TABLE IF NOT EXISTS Movie (
                        MovieID INTEGER PRIMARY KEY AUTOINCREMENT,
                        Title VARCHAR(255) NOT NULL,
                        ReleaseYear DATE,
                        Language VARCHAR(100),
                        CountryOfOrigin VARCHAR(100),
                        Genre VARCHAR(100),
                        DirectorId INTEGER,
                        WatchedOrNot BOOLEAN DEFAULT 0,
                        LeadingActorId INTEGER,
                        SupportingActorId INTEGER,
                        About TEXT,
                        Rating INTEGER CHECK(Rating BETWEEN 1 AND 10),
                        Comments TEXT,
                        Poster VARCHAR(255),
                        ParentalRestriction BOOLEAN DEFAULT 0,
                        FOREIGN KEY (DirectorId) REFERENCES Person(PersonID),
                        FOREIGN KEY (LeadingActorId) REFERENCES Person(PersonID),
                        FOREIGN KEY (SupportingActorId) REFERENCES Person(PersonID)
                    )
                    """);
            st.execute("""
                    CREATE TABLE IF NOT EXISTS Watchlist (
                        WatchlistId INTEGER PRIMARY KEY AUTOINCREMENT,
                        UserId INTEGER NOT NULL,
                        MovieID INTEGER NOT NULL,
                        AddedDate DATE DEFAULT (date('now')),
                        FOREIGN KEY (UserId) REFERENCES User(UserId),
                        FOREIGN KEY (MovieID) REFERENCES Movie(MovieID),
                        UNIQUE(UserId, MovieID)
                    )
                    """);
            st.execute("""
                    CREATE TABLE IF NOT EXISTS UserMovieActivity (
                        ActivityId INTEGER PRIMARY KEY AUTOINCREMENT,
                        UserId INTEGER NOT NULL,
                        MovieID INTEGER NOT NULL,
                        Watched BOOLEAN DEFAULT 0,
                        Rating INTEGER CHECK(Rating BETWEEN 1 AND 5),
                        Comment TEXT,
                        ActivityDate DATE DEFAULT (date('now')),
                        CommentApproved BOOLEAN DEFAULT 1,
                        FOREIGN KEY (UserId) REFERENCES User(UserId),
                        FOREIGN KEY (MovieID) REFERENCES Movie(MovieID),
                        UNIQUE(UserId, MovieID)
                    )
                    """);
        }
        migrateSchema();
        seedIfEmpty();
        createViews();
    }

    private void migrateSchema() throws SQLException {
        if (!columnExists("UserMovieActivity", "CommentApproved")) {
            try (Connection conn = connect(); Statement st = conn.createStatement()) {
                st.execute("ALTER TABLE UserMovieActivity ADD COLUMN CommentApproved BOOLEAN DEFAULT 1");
                st.execute("UPDATE UserMovieActivity SET CommentApproved = 1 WHERE CommentApproved IS NULL");
            }
        }
    }

    private boolean columnExists(String tableName, String columnName) throws SQLException {
        try (Connection conn = connect(); Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("PRAGMA table_info(" + tableName + ")")) {
            while (rs.next()) {
                if (columnName.equalsIgnoreCase(rs.getString("name"))) {
                    return true;
                }
            }
        }
        return false;
    }

    private void createViews() throws SQLException {
        try (Connection conn = connect(); Statement st = conn.createStatement()) {
            String[] viewNames = {
                "vw_movie_details",
                "vw_child_available_movies",
                "vw_restricted_movies",
                "vw_family_ratings",
                "vw_movie_average_ratings",
                "vw_watchlist_details",
                "vw_user_progress",
                "vw_most_watched_movies",
                "vw_comments_for_moderation",
                "vw_parent_dashboard"
            };
            for (String viewName : viewNames) {
                st.execute("DROP VIEW IF EXISTS " + viewName);
            }

            st.execute("""
                    CREATE VIEW vw_movie_details AS
                    SELECT
                        m.MovieID,
                        m.Title,
                        m.ReleaseYear,
                        m.Language,
                        m.CountryOfOrigin,
                        m.Genre,
                        d.FirstName || ' ' || d.LastName AS DirectorName,
                        la.FirstName || ' ' || la.LastName AS LeadingActorName,
                        sa.FirstName || ' ' || sa.LastName AS SupportingActorName,
                        m.About,
                        m.Rating AS MovieRating,
                        m.Comments AS MovieComments,
                        m.Poster,
                        m.WatchedOrNot,
                        m.ParentalRestriction
                    FROM Movie m
                    LEFT JOIN Person d  ON m.DirectorId = d.PersonID
                    LEFT JOIN Person la ON m.LeadingActorId = la.PersonID
                    LEFT JOIN Person sa ON m.SupportingActorId = sa.PersonID
                    """);

            st.execute("""
                    CREATE VIEW vw_child_available_movies AS
                    SELECT
                        MovieID,
                        Title,
                        ReleaseYear,
                        Language,
                        CountryOfOrigin,
                        Genre,
                        DirectorName,
                        LeadingActorName,
                        SupportingActorName,
                        About,
                        MovieRating,
                        MovieComments,
                        Poster
                    FROM vw_movie_details
                    WHERE COALESCE(ParentalRestriction, 0) = 0
                    """);

            st.execute("""
                    CREATE VIEW vw_restricted_movies AS
                    SELECT
                        MovieID,
                        Title,
                        ReleaseYear,
                        Genre,
                        DirectorName,
                        ParentalRestriction
                    FROM vw_movie_details
                    WHERE COALESCE(ParentalRestriction, 0) = 1
                    """);

            st.execute("""
                    CREATE VIEW vw_family_ratings AS
                    SELECT
                        uma.ActivityId,
                        u.UserId,
                        u.Username,
                        u.UserType,
                        m.MovieID,
                        m.Title,
                        uma.Watched,
                        uma.Rating,
                        uma.Comment,
                        uma.ActivityDate,
                        COALESCE(uma.CommentApproved, 1) AS CommentApproved
                    FROM UserMovieActivity uma
                    JOIN "User" u ON uma.UserId = u.UserId
                    JOIN Movie m ON uma.MovieID = m.MovieID
                    """);

            st.execute("""
                    CREATE VIEW vw_movie_average_ratings AS
                    SELECT
                        m.MovieID,
                        m.Title,
                        COUNT(uma.Rating) AS RatingCount,
                        ROUND(AVG(uma.Rating), 2) AS AverageRating,
                        MIN(uma.Rating) AS LowestRating,
                        MAX(uma.Rating) AS HighestRating
                    FROM Movie m
                    LEFT JOIN UserMovieActivity uma ON m.MovieID = uma.MovieID
                    GROUP BY m.MovieID, m.Title
                    """);

            st.execute("""
                    CREATE VIEW vw_watchlist_details AS
                    SELECT
                        w.WatchlistId,
                        u.UserId,
                        u.Username,
                        m.MovieID,
                        m.Title,
                        m.Genre,
                        m.ReleaseYear,
                        w.AddedDate,
                        m.ParentalRestriction
                    FROM Watchlist w
                    JOIN "User" u ON w.UserId = u.UserId
                    JOIN Movie m ON w.MovieID = m.MovieID
                    """);

            st.execute("""
                    CREATE VIEW vw_user_progress AS
                    SELECT
                        u.UserId,
                        u.Username,
                        CASE
                            WHEN u.UserType = 1 THEN 'Parent/Adult'
                            WHEN u.UserType = 2 THEN 'Child'
                            ELSE 'Unknown'
                        END AS UserRole,
                        COUNT(uma.MovieID) AS TotalActivityRecords,
                        SUM(CASE WHEN uma.Watched = 1 THEN 1 ELSE 0 END) AS WatchedMovieCount,
                        SUM(CASE WHEN uma.Rating IS NOT NULL THEN 1 ELSE 0 END) AS RatedMovieCount,
                        SUM(CASE WHEN uma.Comment IS NOT NULL AND uma.Comment <> '' THEN 1 ELSE 0 END) AS CommentCount,
                        ROUND(AVG(uma.Rating), 2) AS AverageGivenRating
                    FROM "User" u
                    LEFT JOIN UserMovieActivity uma ON u.UserId = uma.UserId
                    GROUP BY u.UserId, u.Username, u.UserType
                    """);

            st.execute("""
                    CREATE VIEW vw_most_watched_movies AS
                    SELECT
                        m.MovieID,
                        m.Title,
                        COUNT(uma.ActivityId) AS WatchedCount
                    FROM Movie m
                    LEFT JOIN UserMovieActivity uma
                        ON m.MovieID = uma.MovieID
                       AND uma.Watched = 1
                    GROUP BY m.MovieID, m.Title
                    ORDER BY WatchedCount DESC, m.Title ASC
                    """);

            st.execute("""
                    CREATE VIEW vw_comments_for_moderation AS
                    SELECT
                        uma.ActivityId,
                        uma.UserId,
                        uma.MovieID,
                        u.Username,
                        m.Title,
                        uma.Watched,
                        uma.Rating,
                        uma.Comment,
                        uma.ActivityDate,
                        COALESCE(uma.CommentApproved, 1) AS CommentApproved
                    FROM UserMovieActivity uma
                    JOIN "User" u ON uma.UserId = u.UserId
                    JOIN Movie m ON uma.MovieID = m.MovieID
                    WHERE uma.Comment IS NOT NULL OR uma.Rating IS NOT NULL
                    """);

            st.execute("""
                    CREATE VIEW vw_parent_dashboard AS
                    SELECT
                        (SELECT COUNT(*) FROM Movie) AS TotalMovies,
                        (SELECT COUNT(*) FROM Movie WHERE COALESCE(ParentalRestriction, 0) = 1) AS RestrictedMovies,
                        (SELECT COUNT(*) FROM Movie WHERE COALESCE(ParentalRestriction, 0) = 0) AS ChildAvailableMovies,
                        (SELECT COUNT(*) FROM "User" WHERE UserType = 1) AS ParentUserCount,
                        (SELECT COUNT(*) FROM "User" WHERE UserType = 2) AS ChildUserCount,
                        (SELECT COUNT(*) FROM Watchlist) AS TotalWatchlistItems,
                        (SELECT COUNT(*) FROM UserMovieActivity WHERE Watched = 1) AS TotalWatchedRecords,
                        (SELECT ROUND(AVG(Rating), 2) FROM UserMovieActivity WHERE Rating IS NOT NULL) AS OverallAverageFamilyRating
                    """);
        }
    }

    private void seedIfEmpty() throws SQLException {
        if (count("Person") == 0) {
            executeUpdate("""
                    INSERT INTO Person (FirstName, LastName, DateOfBirth, Nationality) VALUES
                    ('Christopher', 'Nolan', '1970-07-30', 'British'),
                    ('Leonardo', 'DiCaprio', '1974-11-11', 'American'),
                    ('Joseph', 'Gordon-Levitt', '1981-02-17', 'American'),
                    ('Steven', 'Spielberg', '1946-12-18', 'American'),
                    ('Tom', 'Hanks', '1956-07-09', 'American'),
                    ('Robin', 'Wright', '1966-04-08', 'American'),
                    ('Ridley', 'Scott', '1937-11-30', 'British'),
                    ('Russell', 'Crowe', '1964-04-07', 'Australian'),
                    ('Joaquin', 'Phoenix', '1974-10-28', 'American'),
                    ('Greta', 'Gerwig', '1983-08-04', 'American'),
                    ('Margot', 'Robbie', '1990-07-02', 'Australian'),
                    ('Ryan', 'Gosling', '1980-11-12', 'Canadian'),
                    ('James', 'Cameron', '1954-08-16', 'Canadian'),
                    ('Sam', 'Worthington', '1976-08-02', 'Australian'),
                    ('Zoe', 'Saldana', '1978-06-19', 'American')
                    """);
        }
        if (count("User") == 0) {
            executeUpdate("""
                    INSERT INTO User (Username, Password, UserType, Email) VALUES
                    ('father', 'father123', 1, 'father@family.com'),
                    ('mother', 'mother123', 1, 'mother@family.com'),
                    ('son', 'son123', 2, 'son@family.com'),
                    ('daughter', 'daughter123', 2, 'daughter@family.com'),
                    ('kid', 'kid123', 2, 'kid@family.com')
                    """);
        }
        if (count("Movie") == 0) {
            executeUpdate("""
                    INSERT INTO Movie (Title, ReleaseYear, Language, CountryOfOrigin, Genre, DirectorId,
                    WatchedOrNot, LeadingActorId, SupportingActorId, About, Rating, Comments, Poster, ParentalRestriction) VALUES
                    ('Inception', '2010-07-16', 'English', 'USA', 'Sci-Fi/Thriller', 1, 1, 2, 3,
                    'A thief who steals corporate secrets through dream-sharing technology is given the inverse task of planting an idea.',
                    9, 'Mind-blowing concept, must watch!', 'posters/inception.jpg', 1),
                    ('Forrest Gump', '1994-07-06', 'English', 'USA', 'Drama/Romance', 4, 1, 5, 6,
                    'History unfolds through the perspective of an Alabama man.', 9, 'A timeless classic full of heart.',
                    'posters/forrest_gump.jpg', 0),
                    ('Gladiator', '2000-05-05', 'English', 'USA', 'Action/Drama', 7, 0, 8, 9,
                    'A former Roman general seeks vengeance against the corrupt emperor who murdered his family.',
                    8, 'Epic and powerful!', 'posters/gladiator.jpg', 1),
                    ('Barbie', '2023-07-21', 'English', 'USA', 'Comedy/Fantasy', 10, 1, 11, 12,
                    'Barbie and Ken go on a journey of self-discovery.', 7, 'Fun and surprisingly deep!',
                    'posters/barbie.jpg', 0),
                    ('Avatar', '2009-12-18', 'English', 'USA', 'Sci-Fi/Adventure', 13, 1, 14, 15,
                    'A Marine on Pandora becomes torn between orders and protecting a new home.', 8, 'Visually stunning!',
                    'posters/avatar.jpg', 0),
                    ('The Dark Knight', '2008-07-18', 'English', 'USA', 'Action/Crime', 1, 1, 2, 3,
                    'Batman faces the Joker, who wants to plunge Gotham City into anarchy.', 10,
                    'Greatest superhero movie ever made.', 'posters/dark_knight.jpg', 1),
                    ('Schindler''s List', '1993-12-15', 'English', 'USA', 'Drama/History', 4, 0, 5, 6,
                    'Oskar Schindler becomes concerned for his Jewish workforce in German-occupied Poland.', 10,
                    'Heartbreaking and important.', 'posters/schindlers_list.jpg', 1),
                    ('La La Land', '2016-12-09', 'English', 'USA', 'Musical/Romance', 10, 1, 11, 12,
                    'A pianist and an actress fall in love while navigating their careers in Los Angeles.', 8,
                    'Beautiful and bittersweet.', 'posters/la_la_land.jpg', 0),
                    ('Interstellar', '2014-11-07', 'English', 'USA', 'Sci-Fi/Adventure', 1, 0, 5, 2,
                    'Explorers travel through a wormhole to help humanity survive.', 9,
                    'Emotionally gripping and scientifically fascinating.', 'posters/interstellar.jpg', 0),
                    ('Joker', '2019-10-04', 'English', 'USA', 'Crime/Drama', 7, 1, 9, 8,
                    'A socially isolated failed comedian descends into madness.', 8, 'Brilliant but very dark.',
                    'posters/joker.jpg', 1)
                    """);
        }
        if (count("UserMovieActivity") == 0) {
            executeUpdate("""
                    INSERT INTO UserMovieActivity (UserId, MovieID, Watched, Rating, Comment) VALUES
                    (1, 1, 1, 5, 'Absolutely mind-bending!'),
                    (1, 6, 1, 5, 'Best Batman film.'),
                    (2, 2, 1, 5, 'Cried throughout!'),
                    (2, 4, 1, 4, 'Very creative film.'),
                    (3, 4, 1, 5, 'Loved Barbie!'),
                    (3, 5, 1, 4, 'Avatar graphics are amazing!'),
                    (4, 8, 1, 5, 'La La Land is my favourite!'),
                    (4, 5, 1, 3, 'Good but long.'),
                    (5, 5, 1, 4, 'Cool movie!'),
                    (5, 9, 1, 5, 'Interstellar was epic!')
                    """);
        }
        if (count("Watchlist") == 0) {
            executeUpdate("""
                    INSERT INTO Watchlist (UserId, MovieID) VALUES
                    (3, 9), (3, 6), (4, 1), (5, 2), (5, 4)
                    """);
        }
    }

    private void executeUpdate(String sql) throws SQLException {
        try (Connection conn = connect(); Statement st = conn.createStatement()) {
            st.executeUpdate(sql);
        }
    }

    private static final class DriverShim implements Driver {
        private final Driver driver;

        DriverShim(Driver driver) {
            this.driver = driver;
        }

        @Override
        public Connection connect(String url, Properties info) throws SQLException {
            return driver.connect(url, info);
        }

        @Override
        public boolean acceptsURL(String url) throws SQLException {
            return driver.acceptsURL(url);
        }

        @Override
        public java.sql.DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException {
            return driver.getPropertyInfo(url, info);
        }

        @Override
        public int getMajorVersion() {
            return driver.getMajorVersion();
        }

        @Override
        public int getMinorVersion() {
            return driver.getMinorVersion();
        }

        @Override
        public boolean jdbcCompliant() {
            return driver.jdbcCompliant();
        }

        @Override
        public Logger getParentLogger() throws SQLFeatureNotSupportedException {
            return driver.getParentLogger();
        }
    }
}
