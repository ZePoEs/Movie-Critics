package javaapplication6;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

final class LoginFrame extends JFrame {
    private final DatabaseManager database;
    private final JTextField usernameField = new JTextField("father", 28);
    private final JPasswordField passwordField = new JPasswordField("father123", 28);

    LoginFrame(DatabaseManager database) {
        super("MovieCritics - LoginFrame");
        this.database = database;
        buildUi();
    }

    private void buildUi() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(580, 350);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(16, 16));
        root.setBorder(BorderFactory.createEmptyBorder(22, 26, 22, 26));
        setContentPane(root);

        JLabel title = new JLabel("MovieCritics");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 28f));
        JLabel subtitle = new JLabel("Family movie library and ratings");
        subtitle.setForeground(UiTheme.MUTED);

        JPanel header = new JPanel(new BorderLayout(0, 4));
        header.add(title, BorderLayout.NORTH);
        header.add(subtitle, BorderLayout.SOUTH);
        root.add(header, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 4, 7, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("Username"), gbc);
        gbc.gridx = 1;
        form.add(usernameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("Password"), gbc);
        gbc.gridx = 1;
        form.add(passwordField, gbc);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(e -> login());
        getRootPane().setDefaultButton(loginButton);
        gbc.gridx = 1;
        gbc.gridy = 2;
        form.add(loginButton, gbc);

        root.add(form, BorderLayout.CENTER);

        JLabel hint = new JLabel("<html>Test accounts: father/father123, mother/mother123, son/son123, daughter/daughter123, kid/kid123</html>");
        hint.setForeground(UiTheme.MUTED);
        root.add(hint, BorderLayout.SOUTH);
        UiTheme.apply(root);
    }

    private void login() {
        try {
            UserAccount user = database.authenticate(
                    usernameField.getText().trim(),
                    new String(passwordField.getPassword())
            );
            if (user == null) {
                JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login failed", JOptionPane.WARNING_MESSAGE);
                return;
            }
            dispose();
            if (user.isParent()) {
                new Type1MainFrame(database, user).setVisible(true);
            } else {
                new Type2MainFrame(database, user).setVisible(true);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
