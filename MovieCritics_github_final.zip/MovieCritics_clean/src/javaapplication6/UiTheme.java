package javaapplication6;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;

final class UiTheme {
    static final Color BACKGROUND = Color.WHITE;
    static final Color PANEL = new Color(245, 247, 250);
    static final Color FIELD = Color.WHITE;
    static final Color BUTTON = new Color(248, 248, 248);
    static final Color TEXT = new Color(20, 20, 24);
    static final Color MUTED = new Color(88, 88, 96);
    static final Color BORDER = new Color(196, 200, 208);
    static final Color SELECTION = new Color(205, 228, 255);
    static final Color RESTRICTED_ROW = new Color(255, 242, 225);

    private UiTheme() {
    }

    static void install() {
        UIManager.put("Panel.background", BACKGROUND);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("Button.background", BUTTON);
        UIManager.put("Button.foreground", TEXT);
        UIManager.put("CheckBox.background", BACKGROUND);
        UIManager.put("CheckBox.foreground", TEXT);
        UIManager.put("TextField.background", FIELD);
        UIManager.put("TextField.foreground", TEXT);
        UIManager.put("PasswordField.background", FIELD);
        UIManager.put("PasswordField.foreground", TEXT);
        UIManager.put("TextArea.background", FIELD);
        UIManager.put("TextArea.foreground", TEXT);
        UIManager.put("ComboBox.background", FIELD);
        UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("Table.background", FIELD);
        UIManager.put("Table.foreground", TEXT);
        UIManager.put("Table.gridColor", BORDER);
        UIManager.put("Table.selectionBackground", SELECTION);
        UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("TabbedPane.background", BACKGROUND);
        UIManager.put("TabbedPane.foreground", TEXT);
        UIManager.put("Viewport.background", BACKGROUND);
    }

    static void apply(Component component) {
        if (component == null) {
            return;
        }
        if (component instanceof JLabel label) {
            label.setForeground(TEXT);
        } else if (component instanceof JButton button) {
            button.setBackground(BUTTON);
            button.setForeground(TEXT);
            button.setFocusPainted(false);
            button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER),
                    BorderFactory.createEmptyBorder(5, 12, 5, 12)
            ));
        } else if (component instanceof JCheckBox checkBox) {
            checkBox.setBackground(BACKGROUND);
            checkBox.setForeground(TEXT);
        } else if (component instanceof JTextComponent text) {
            text.setBackground(FIELD);
            text.setForeground(TEXT);
            text.setCaretColor(TEXT);
            text.setSelectionColor(SELECTION);
            text.setSelectedTextColor(TEXT);
            text.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER),
                    BorderFactory.createEmptyBorder(5, 7, 5, 7)
            ));
        } else if (component instanceof JComboBox<?> comboBox) {
            comboBox.setBackground(FIELD);
            comboBox.setForeground(TEXT);
        } else if (component instanceof JSpinner spinner) {
            spinner.setBackground(FIELD);
            spinner.setForeground(TEXT);
            apply(spinner.getEditor());
        } else if (component instanceof JTable table) {
            table.setBackground(FIELD);
            table.setForeground(TEXT);
            table.setGridColor(BORDER);
            table.setSelectionBackground(SELECTION);
            table.setSelectionForeground(TEXT);
            JTableHeader header = table.getTableHeader();
            if (header != null) {
                header.setBackground(PANEL);
                header.setForeground(TEXT);
            }
        } else if (component instanceof JScrollPane scrollPane) {
            scrollPane.setBackground(BACKGROUND);
            scrollPane.setBorder(BorderFactory.createLineBorder(BORDER));
            JViewport viewport = scrollPane.getViewport();
            if (viewport != null) {
                viewport.setBackground(BACKGROUND);
            }
        } else if (component instanceof JSplitPane splitPane) {
            splitPane.setBackground(BACKGROUND);
            splitPane.setBorder(BorderFactory.createLineBorder(BORDER));
        } else if (component instanceof JTabbedPane tabs) {
            tabs.setBackground(BACKGROUND);
            tabs.setForeground(TEXT);
        }

        if (component instanceof JComponent jComponent) {
            jComponent.setOpaque(true);
            if (!(component instanceof JTextArea) && !(component instanceof JTextField)
                    && !(component instanceof JTable) && !(component instanceof JButton)
                    && !(component instanceof JComboBox<?>)) {
                jComponent.setBackground(BACKGROUND);
            }
            Border border = jComponent.getBorder();
            if (border instanceof TitledBorder titledBorder) {
                titledBorder.setTitleColor(TEXT);
                titledBorder.setBorder(BorderFactory.createLineBorder(BORDER));
            }
        }

        if (component instanceof Container container) {
            for (Component child : container.getComponents()) {
                apply(child);
            }
        }
    }
}
