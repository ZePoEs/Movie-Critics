package javaapplication6;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

final class Type1MainFrame extends BaseMainFrame {
    private JTabbedPane tabs;
    private final JTextField titleField = new JTextField(18);
    private final JTextField releaseField = new JTextField(10);
    private final JTextField languageField = new JTextField(10);
    private final JTextField countryField = new JTextField(10);
    private final JTextField movieGenreField = new JTextField(12);
    private final JTextField directorField = new JTextField(18);
    private final JTextField leadingActorField = new JTextField(18);
    private final JTextField supportingActorField = new JTextField(18);
    private final JCheckBox watchedBox = new JCheckBox("Watched in library");
    private final JCheckBox restrictedBox = new JCheckBox("Parental restriction");
    private final JSpinner libraryRatingSpinner = new JSpinner(new SpinnerNumberModel(4, 1, 5, 1));
    private final JTextField posterField = new JTextField(18);
    private final JTextArea aboutArea = new JTextArea(3, 18);
    private final JTextArea libraryCommentsArea = new JTextArea(3, 18);
    private int editingMovieId;
    private final JTable editorMovieTable = new JTable();
    private final DefaultTableModel editorMovieModel = new ReadOnlyTableModel();
    private final List<Movie> editorMovieRows = new ArrayList<>();
    private final JTextField editorMovieSearchField = new JTextField(16);
    private boolean suppressEditorLoadFromBrowse;

    private final JTable usersTable = new JTable();
    private final DefaultTableModel usersModel = new ReadOnlyTableModel();
    private final List<UserAccount> userRows = new ArrayList<>();
    private final JTextField accountUsername = new JTextField(14);
    private final JTextField accountPassword = new JTextField(14);
    private final JTextField accountEmail = new JTextField(16);
    private final JComboBox<String> accountType = new JComboBox<>(new String[]{"Parent/Adult", "Child"});
    private int editingUserId;

    private final JTable moderationTable = new JTable();
    private final DefaultTableModel moderationModel = new ReadOnlyTableModel();
    private final List<ActivityRecord> moderationRows = new ArrayList<>();
    private final JLabel totalMoviesValue = new JLabel("-");
    private final JLabel watchedMoviesValue = new JLabel("-");
    private final JLabel restrictedMoviesValue = new JLabel("-");
    private final JLabel familyUsersValue = new JLabel("-");
    private final JLabel familyAverageValue = new JLabel("-");
    private final JLabel activityCountValue = new JLabel("-");
    private final JLabel watchlistCountValue = new JLabel("-");
    private final JLabel pendingCommentsValue = new JLabel("-");
    private final JTable mostWatchedTable = new JTable();
    private final DefaultTableModel mostWatchedModel = new ReadOnlyTableModel();
    private final JTable averageRatingsTable = new JTable();
    private final DefaultTableModel averageRatingsModel = new ReadOnlyTableModel();
    private final JTable familyActivityTable = new JTable();
    private final DefaultTableModel familyActivityModel = new ReadOnlyTableModel();
    private final JTable childProgressTable = new JTable();
    private final DefaultTableModel childProgressModel = new ReadOnlyTableModel();
    private final JTable pendingCommentsTable = new JTable();
    private final DefaultTableModel pendingCommentsModel = new ReadOnlyTableModel();

    Type1MainFrame(DatabaseManager database, UserAccount currentUser) {
        super(database, currentUser, true, "Parent / Adult");
        buildUi();
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout());
        root.add(createHeader("Parent / Adult"), BorderLayout.NORTH);
        tabs = new JTabbedPane();
        tabs.addTab("Parent Home", createParentHomePanel());
        tabs.addTab("Browse Movies", createMovieBrowserPanel(null));
        JScrollPane movieEditorScroll = new JScrollPane(createMovieEditorPanel());
        movieEditorScroll.getVerticalScrollBar().setUnitIncrement(18);
        tabs.addTab("Movie Editor", movieEditorScroll);
        tabs.addTab("User Accounts", createUsersPanel());
        tabs.addTab("Moderation", createModerationPanel());
        tabs.addTab("Analytics", createAnalyticsPanel());
        root.add(tabs, BorderLayout.CENTER);
        setContentPane(root);
        UiTheme.apply(root);
        refreshEditorMovies();
        refreshUsers();
        refreshModeration();
        refreshAnalytics();
    }

    private JPanel createParentHomePanel() {
        JPanel panel = new JPanel(new BorderLayout(18, 18));
        panel.setBorder(BorderFactory.createEmptyBorder(34, 46, 46, 46));

        JLabel title = new JLabel("Parent / Adult Panel", JLabel.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 28f));
        JLabel loggedIn = new JLabel("Logged in as: " + currentUser.username + " (" + currentUser.roleName() + ")", JLabel.CENTER);

        JPanel header = new JPanel(new BorderLayout(0, 14));
        header.add(title, BorderLayout.NORTH);
        header.add(loggedIn, BorderLayout.CENTER);

        JPanel actions = new JPanel(new GridLayout(5, 2, 18, 18));
        actions.add(menuButton("Add / Remove Movies", () -> tabs.setSelectedIndex(2)));
        actions.add(menuButton("Edit Movie Details", () -> tabs.setSelectedIndex(2)));
        actions.add(menuButton("Manage User Accounts", () -> tabs.setSelectedIndex(3)));
        actions.add(menuButton("Set Viewing Rules", () -> tabs.setSelectedIndex(2)));
        actions.add(menuButton("Moderate Content", () -> tabs.setSelectedIndex(4)));
        actions.add(menuButton("View Family Analytics", () -> tabs.setSelectedIndex(5)));
        actions.add(menuButton("Browse Movies", () -> tabs.setSelectedIndex(1)));
        actions.add(menuButton("View Family Ratings", () -> tabs.setSelectedIndex(1)));
        actions.add(menuButton("Logout", this::logout));
        actions.add(new JLabel(""));

        panel.add(header, BorderLayout.NORTH);
        panel.add(actions, BorderLayout.CENTER);
        return panel;
    }

    private JButton menuButton(String text, Runnable action) {
        JButton button = new JButton(text);
        button.setFont(button.getFont().deriveFont(Font.BOLD, 16f));
        button.addActionListener(e -> action.run());
        return button;
    }

    private void logout() {
        dispose();
        javax.swing.SwingUtilities.invokeLater(() -> new LoginFrame(database).setVisible(true));
    }

    private JPanel createMovieEditorPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Add, edit, remove movies and viewing rules"));

        editorMovieModel.setColumnIdentifiers(new Object[]{"ID", "Title", "Year", "Genre", "Restricted"});
        editorMovieTable.setModel(editorMovieModel);
        editorMovieTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        editorMovieTable.setRowHeight(28);
        editorMovieTable.setAutoCreateRowSorter(true);
        editorMovieTable.getColumnModel().getColumn(0).setMaxWidth(50);
        editorMovieTable.getColumnModel().getColumn(2).setMaxWidth(70);
        editorMovieTable.getColumnModel().getColumn(4).setMaxWidth(85);
        editorMovieTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selectEditorMovieRow();
            }
        });

        JPanel editorFilters = new JPanel(new GridBagLayout());
        GridBagConstraints filterGbc = new GridBagConstraints();
        filterGbc.insets = new Insets(3, 4, 3, 4);
        filterGbc.fill = GridBagConstraints.HORIZONTAL;
        filterGbc.gridx = 0;
        editorFilters.add(new JLabel("Find"), filterGbc);
        filterGbc.gridx = 1;
        filterGbc.weightx = 1;
        editorFilters.add(editorMovieSearchField, filterGbc);
        filterGbc.weightx = 0;
        JButton search = new JButton("Search");
        search.addActionListener(e -> refreshEditorMovies());
        filterGbc.gridx = 2;
        editorFilters.add(search, filterGbc);
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> refreshEditorMovies());
        filterGbc.gridx = 3;
        editorFilters.add(refresh, filterGbc);

        JPanel existingMovies = new JPanel(new BorderLayout(6, 6));
        existingMovies.setBorder(BorderFactory.createTitledBorder("Existing movies"));
        existingMovies.add(editorFilters, BorderLayout.NORTH);
        existingMovies.add(new JScrollPane(editorMovieTable), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 4, 3, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        addField(form, gbc, 0, "Title", titleField);
        addField(form, gbc, 1, "Release date", releaseField);
        addField(form, gbc, 2, "Language", languageField);
        addField(form, gbc, 3, "Country", countryField);
        addField(form, gbc, 4, "Genre", movieGenreField);
        addField(form, gbc, 5, "Director", directorField);
        addField(form, gbc, 6, "Leading actor", leadingActorField);
        addField(form, gbc, 7, "Supporting actor", supportingActorField);
        addField(form, gbc, 8, "Poster path", posterField);
        addField(form, gbc, 9, "Library rating 1-5", libraryRatingSpinner);
        gbc.gridx = 0;
        gbc.gridy = 10;
        form.add(watchedBox, gbc);
        gbc.gridx = 1;
        form.add(restrictedBox, gbc);

        aboutArea.setLineWrap(true);
        aboutArea.setWrapStyleWord(true);
        aboutArea.setFont(aboutArea.getFont().deriveFont(17f));
        libraryCommentsArea.setLineWrap(true);
        libraryCommentsArea.setWrapStyleWord(true);
        libraryCommentsArea.setFont(libraryCommentsArea.getFont().deriveFont(17f));

        JPanel textAreas = new JPanel(new GridBagLayout());
        addArea(textAreas, "About", aboutArea, 0);
        addArea(textAreas, "Library comments", libraryCommentsArea, 1);

        JPanel buttons = new JPanel();
        JButton clear = new JButton("New Movie");
        clear.addActionListener(e -> clearMovieForm());
        JButton add = new JButton("Add as New Movie");
        add.addActionListener(e -> addMovie());
        JButton save = new JButton("Save Selected Movie");
        save.addActionListener(e -> saveMovie());
        JButton delete = new JButton("Remove Selected Movie");
        delete.addActionListener(e -> deleteMovie());
        buttons.add(clear);
        buttons.add(add);
        buttons.add(save);
        buttons.add(delete);

        JPanel editorForm = new JPanel(new BorderLayout(8, 8));
        editorForm.setBorder(BorderFactory.createTitledBorder("Selected movie details"));
        editorForm.add(form, BorderLayout.NORTH);
        editorForm.add(textAreas, BorderLayout.CENTER);
        editorForm.add(buttons, BorderLayout.SOUTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, existingMovies, editorForm);
        split.setResizeWeight(0.38);
        panel.add(split, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createUsersPanel() {
        usersModel.setColumnIdentifiers(new Object[]{"ID", "Username", "Role", "Email"});
        usersTable.setModel(usersModel);
        usersTable.setRowHeight(28);
        usersTable.setAutoCreateRowSorter(true);
        usersTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selectUserRow();
            }
        });

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Create accounts, assign roles, reset passwords"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        addField(form, gbc, 0, "Username", accountUsername);
        addField(form, gbc, 1, "Password", accountPassword);
        addField(form, gbc, 2, "Email", accountEmail);
        addField(form, gbc, 3, "Role", accountType);
        JPanel buttons = new JPanel();
        JButton clear = new JButton("New");
        clear.addActionListener(e -> clearUserForm());
        JButton save = new JButton("Save Account");
        save.addActionListener(e -> saveUser());
        JButton delete = new JButton("Delete Account");
        delete.addActionListener(e -> deleteUser());
        buttons.add(clear);
        buttons.add(save);
        buttons.add(delete);

        JPanel right = new JPanel(new BorderLayout());
        right.add(form, BorderLayout.CENTER);
        right.add(buttons, BorderLayout.SOUTH);
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        panel.add(new JScrollPane(usersTable), BorderLayout.CENTER);
        panel.add(right, BorderLayout.EAST);
        return panel;
    }

    private JPanel createModerationPanel() {
        moderationModel.setColumnIdentifiers(new Object[]{"ID", "User", "Movie", "Watched", "Rating", "Comment", "Status", "Date"});
        moderationTable.setModel(moderationModel);
        moderationTable.setRowHeight(28);
        moderationTable.setAutoCreateRowSorter(true);
        moderationTable.getColumnModel().getColumn(0).setMaxWidth(50);

        JPanel buttons = new JPanel();
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> refreshModeration());
        JButton approve = new JButton("Approve Comment");
        approve.addActionListener(e -> approveSelectedComment());
        JButton clearComment = new JButton("Clear Comment");
        clearComment.addActionListener(e -> clearSelectedComment());
        JButton delete = new JButton("Delete Rating Row");
        delete.addActionListener(e -> deleteSelectedActivity());
        buttons.add(refresh);
        buttons.add(approve);
        buttons.add(clearComment);
        buttons.add(delete);

        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        panel.add(new JScrollPane(moderationTable), BorderLayout.CENTER);
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createAnalyticsPanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel top = new JPanel(new BorderLayout(8, 8));
        JLabel title = new JLabel("Family Analytics Dashboard");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
        JButton refresh = new JButton("Refresh Analytics");
        refresh.addActionListener(e -> refreshAnalytics());
        top.add(title, BorderLayout.WEST);
        top.add(refresh, BorderLayout.EAST);

        JPanel summary = new JPanel(new GridLayout(2, 4, 10, 10));
        summary.add(metricPanel("Movies", totalMoviesValue));
        summary.add(metricPanel("Watched Movies", watchedMoviesValue));
        summary.add(metricPanel("Restricted Movies", restrictedMoviesValue));
        summary.add(metricPanel("Family Users", familyUsersValue));
        summary.add(metricPanel("Family Avg Rating", familyAverageValue));
        summary.add(metricPanel("Activities", activityCountValue));
        summary.add(metricPanel("Watchlist Items", watchlistCountValue));
        summary.add(metricPanel("Pending Kid Comments", pendingCommentsValue));

        mostWatchedModel.setColumnIdentifiers(new Object[]{"Movie", "Watched Count", "Genre", "Release Date"});
        averageRatingsModel.setColumnIdentifiers(new Object[]{"Movie", "Avg Family Rating", "Rating Count", "Library Rating"});
        familyActivityModel.setColumnIdentifiers(new Object[]{"User", "Role", "Activities", "Watched", "Avg Rating"});
        childProgressModel.setColumnIdentifiers(new Object[]{"Child", "Watched Movies", "Visible Movies", "Progress"});
        pendingCommentsModel.setColumnIdentifiers(new Object[]{"Child", "Movie", "Comment", "Date"});
        configureAnalyticsTable(mostWatchedTable, mostWatchedModel);
        configureAnalyticsTable(averageRatingsTable, averageRatingsModel);
        configureAnalyticsTable(familyActivityTable, familyActivityModel);
        configureAnalyticsTable(childProgressTable, childProgressModel);
        configureAnalyticsTable(pendingCommentsTable, pendingCommentsModel);

        JTabbedPane analyticsTabs = new JTabbedPane();
        analyticsTabs.addTab("Most Watched Movies", tablePanel(mostWatchedTable));
        analyticsTabs.addTab("Average Family Ratings", tablePanel(averageRatingsTable));
        analyticsTabs.addTab("Family Member Activity", tablePanel(familyActivityTable));
        analyticsTabs.addTab("Child Progress", tablePanel(childProgressTable));
        analyticsTabs.addTab("Pending Comments", tablePanel(pendingCommentsTable));

        JPanel north = new JPanel(new BorderLayout(8, 8));
        north.add(top, BorderLayout.NORTH);
        north.add(summary, BorderLayout.CENTER);
        panel.add(north, BorderLayout.NORTH);
        panel.add(analyticsTabs, BorderLayout.CENTER);
        return panel;
    }

    @Override
    protected void onMovieSelected(Movie movie) {
        if (suppressEditorLoadFromBrowse) {
            return;
        }
        loadMovieIntoEditor(movie);
    }

    private void loadMovieIntoEditor(Movie movie) {
        editingMovieId = movie.id;
        titleField.setText(safe(movie.title));
        releaseField.setText(safe(movie.releaseDate));
        languageField.setText(safe(movie.language));
        countryField.setText(safe(movie.country));
        movieGenreField.setText(safe(movie.genre));
        watchedBox.setSelected(movie.watchedOrNot);
        restrictedBox.setSelected(movie.parentalRestriction);
        libraryRatingSpinner.setValue(movie.rating == null ? 1 : movie.rating);
        posterField.setText(safe(movie.poster));
        aboutArea.setText(safe(movie.about));
        libraryCommentsArea.setText(safe(movie.comments));
        directorField.setText(safe(movie.directorName));
        leadingActorField.setText(safe(movie.leadingActorName));
        supportingActorField.setText(safe(movie.supportingActorName));
    }

    private void refreshEditorMovies() {
        try {
            int selectedMovieId = editingMovieId;
            editorMovieRows.clear();
            editorMovieRows.addAll(database.searchMovies(
                    editorMovieSearchField.getText(),
                    "(all genres)",
                    "(all directors)",
                    "",
                    true
            ));
            editorMovieModel.setRowCount(0);
            for (Movie movie : editorMovieRows) {
                editorMovieModel.addRow(new Object[]{
                    movie.id,
                    movie.title,
                    movieYear(movie),
                    safe(movie.genre),
                    movie.parentalRestriction ? "Yes" : "No"
                });
            }
            if (selectedMovieId != 0) {
                selectEditorMovieById(selectedMovieId);
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void selectEditorMovieRow() {
        int view = editorMovieTable.getSelectedRow();
        if (view < 0) {
            return;
        }
        int model = editorMovieTable.convertRowIndexToModel(view);
        if (model < 0 || model >= editorMovieRows.size()) {
            return;
        }
        loadMovieIntoEditor(editorMovieRows.get(model));
    }

    private void selectEditorMovieById(int movieId) {
        for (int i = 0; i < editorMovieRows.size(); i++) {
            if (editorMovieRows.get(i).id == movieId) {
                int view = editorMovieTable.convertRowIndexToView(i);
                editorMovieTable.setRowSelectionInterval(view, view);
                editorMovieTable.scrollRectToVisible(editorMovieTable.getCellRect(view, 0, true));
                return;
            }
        }
    }

    private void addMovie() {
        try {
            Movie movie = formMovie();
            if (movie == null) {
                return;
            }
            editingMovieId = database.addMovie(movie);
            afterMovieWrite("Movie added.");
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void saveMovie() {
        if (editingMovieId == 0) {
            JOptionPane.showMessageDialog(this, "Select a movie first or use Add Movie.", "No movie selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            Movie movie = formMovie();
            if (movie == null) {
                return;
            }
            movie.id = editingMovieId;
            database.updateMovie(movie);
            afterMovieWrite("Movie details saved.");
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void deleteMovie() {
        if (editingMovieId == 0) {
            JOptionPane.showMessageDialog(this, "Select a movie from Existing movies first.", "No movie selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String movieTitle = titleField.getText().trim().isEmpty() ? "this movie" : titleField.getText().trim();
        int answer = JOptionPane.showConfirmDialog(this, "Remove " + movieTitle + " from the library?", "Confirm remove", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            database.deleteMovie(editingMovieId);
            clearMovieForm();
            afterMovieWrite("Movie removed.");
            clearMovieForm();
            refreshEditorMovies();
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private Movie formMovie() throws SQLException {
        if (titleField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Title is required.", "Missing title", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        String directorName = directorField.getText().trim();
        String leadingActorName = leadingActorField.getText().trim();
        String supportingActorName = supportingActorField.getText().trim();
        if (directorName.isEmpty() || leadingActorName.isEmpty() || supportingActorName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Director, leading actor, and supporting actor are required.",
                    "Missing person name", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        Movie movie = new Movie();
        movie.title = titleField.getText();
        movie.releaseDate = releaseField.getText();
        movie.language = languageField.getText();
        movie.country = countryField.getText();
        movie.genre = movieGenreField.getText();
        movie.directorId = database.findOrCreatePersonId(directorName);
        movie.leadingActorId = database.findOrCreatePersonId(leadingActorName);
        movie.supportingActorId = database.findOrCreatePersonId(supportingActorName);
        movie.watchedOrNot = watchedBox.isSelected();
        movie.parentalRestriction = restrictedBox.isSelected();
        movie.rating = (Integer) libraryRatingSpinner.getValue();
        movie.poster = posterField.getText();
        movie.about = aboutArea.getText();
        movie.comments = libraryCommentsArea.getText();
        return movie;
    }

    private void clearMovieForm() {
        editingMovieId = 0;
        titleField.setText("");
        releaseField.setText("");
        languageField.setText("");
        countryField.setText("");
        movieGenreField.setText("");
        directorField.setText("");
        leadingActorField.setText("");
        supportingActorField.setText("");
        watchedBox.setSelected(false);
        restrictedBox.setSelected(false);
        libraryRatingSpinner.setValue(4);
        posterField.setText("");
        aboutArea.setText("");
        libraryCommentsArea.setText("");
        editorMovieTable.clearSelection();
    }

    private void afterMovieWrite(String message) {
        int movieToKeepInEditor = editingMovieId;
        reloadFilters();
        suppressEditorLoadFromBrowse = true;
        try {
            reloadMovies();
        } finally {
            suppressEditorLoadFromBrowse = false;
        }
        editingMovieId = movieToKeepInEditor;
        refreshEditorMovies();
        refreshModeration();
        refreshAnalytics();
        JOptionPane.showMessageDialog(this, message);
    }

    private void refreshUsers() {
        try {
            userRows.clear();
            userRows.addAll(database.listUsers());
            usersModel.setRowCount(0);
            for (UserAccount user : userRows) {
                usersModel.addRow(new Object[]{user.id, user.username, user.roleName(), user.email});
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void selectUserRow() {
        int view = usersTable.getSelectedRow();
        if (view < 0) {
            return;
        }
        int model = usersTable.convertRowIndexToModel(view);
        UserAccount user = userRows.get(model);
        editingUserId = user.id;
        accountUsername.setText(user.username);
        accountPassword.setText(user.password);
        accountEmail.setText(safe(user.email));
        accountType.setSelectedIndex(user.userType == 1 ? 0 : 1);
    }

    private void saveUser() {
        if (accountUsername.getText().trim().isEmpty() || accountPassword.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username and password are required.", "Missing data", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            UserAccount user = new UserAccount(
                    editingUserId,
                    accountUsername.getText().trim(),
                    accountPassword.getText().trim(),
                    accountType.getSelectedIndex() == 0 ? 1 : 2,
                    accountEmail.getText().trim()
            );
            database.saveUser(user);
            clearUserForm();
            refreshUsers();
            refreshAnalytics();
            JOptionPane.showMessageDialog(this, "Account saved.");
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void deleteUser() {
        if (editingUserId == 0) {
            return;
        }
        if (editingUserId == currentUser.id) {
            JOptionPane.showMessageDialog(this, "You cannot delete the logged-in account.", "Delete blocked", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "Delete this account and related activities?", "Confirm delete", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            database.deleteUser(editingUserId);
            clearUserForm();
            refreshUsers();
            refreshModeration();
            refreshAnalytics();
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void clearUserForm() {
        editingUserId = 0;
        accountUsername.setText("");
        accountPassword.setText("");
        accountEmail.setText("");
        accountType.setSelectedIndex(1);
    }

    private void refreshModeration() {
        try {
            moderationRows.clear();
            moderationRows.addAll(database.moderationRecords());
            moderationModel.setRowCount(0);
            for (ActivityRecord row : moderationRows) {
                moderationModel.addRow(new Object[]{
                    row.activityId,
                    row.username,
                    row.movieTitle,
                    row.watched ? "Yes" : "No",
                    row.rating == null ? "" : row.rating,
                    safe(row.comment),
                    row.commentApproved ? "Public" : "Pending approval",
                    safe(row.date)
                });
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private ActivityRecord selectedModerationRecord() {
        int view = moderationTable.getSelectedRow();
        if (view < 0) {
            return null;
        }
        int model = moderationTable.convertRowIndexToModel(view);
        return moderationRows.get(model);
    }

    private void clearSelectedComment() {
        ActivityRecord record = selectedModerationRecord();
        if (record == null) {
            return;
        }
        try {
            database.clearActivityComment(record.activityId);
            refreshModeration();
            reloadRatings(record.movieId);
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void approveSelectedComment() {
        ActivityRecord record = selectedModerationRecord();
        if (record == null) {
            return;
        }
        if (record.comment == null || record.comment.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "There is no comment to approve.", "No comment", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            database.approveActivityComment(record.activityId);
            refreshModeration();
            reloadRatings(record.movieId);
            refreshAnalytics();
            JOptionPane.showMessageDialog(this, "Comment approved and made public.");
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void deleteSelectedActivity() {
        ActivityRecord record = selectedModerationRecord();
        if (record == null) {
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "Delete this rating/comment row?", "Confirm delete", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            database.deleteActivity(record.activityId);
            refreshModeration();
            reloadMovies();
            refreshAnalytics();
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void refreshAnalytics() {
        try {
            AnalyticsSummary summary = database.analyticsSummary();
            totalMoviesValue.setText(String.valueOf(summary.movieCount));
            watchedMoviesValue.setText(String.valueOf(summary.watchedMovieCount));
            restrictedMoviesValue.setText(String.valueOf(summary.restrictedMovieCount));
            familyUsersValue.setText(summary.parentCount + " parents, " + summary.childCount + " kids");
            familyAverageValue.setText(summary.averageFamilyRating);
            activityCountValue.setText(String.valueOf(summary.activityCount));
            watchlistCountValue.setText(String.valueOf(summary.watchlistCount));
            pendingCommentsValue.setText(String.valueOf(summary.pendingCommentCount));

            fillModel(mostWatchedModel, database.mostWatchedAnalyticsRows());
            fillModel(averageRatingsModel, database.averageRatingAnalyticsRows());
            fillModel(familyActivityModel, database.familyActivityAnalyticsRows());
            fillModel(childProgressModel, database.childProgressAnalyticsRows());
            fillModel(pendingCommentsModel, database.pendingCommentAnalyticsRows());
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private JPanel metricPanel(String title, JLabel valueLabel) {
        JPanel panel = new JPanel(new BorderLayout(4, 4));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UiTheme.BORDER),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(UiTheme.MUTED);
        valueLabel.setFont(valueLabel.getFont().deriveFont(Font.BOLD, 18f));
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(valueLabel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel tablePanel(JTable table) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private void configureAnalyticsTable(JTable table, DefaultTableModel model) {
        table.setModel(model);
        table.setRowHeight(30);
        table.setAutoCreateRowSorter(true);
        table.setFillsViewportHeight(true);
    }

    private void fillModel(DefaultTableModel model, List<Object[]> rows) {
        model.setRowCount(0);
        for (Object[] row : rows) {
            model.addRow(row);
        }
    }

    private static void addField(JPanel panel, GridBagConstraints gbc, int row, String label, java.awt.Component field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        panel.add(field, gbc);
    }

    private static void addArea(JPanel panel, String label, JTextArea area, int row) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        panel.add(new JScrollPane(area), gbc);
    }

}
