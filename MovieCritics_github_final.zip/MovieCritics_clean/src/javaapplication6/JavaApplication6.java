package javaapplication6;

import java.awt.Font;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

public class JavaApplication6 {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                increaseApplicationFontSize(15f);
                UiTheme.install();
                DatabaseManager database = new DatabaseManager();
                new LoginFrame(database).setVisible(true);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                        null,
                        ex.getMessage(),
                        "MovieCritics startup error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });
    }

    private static void increaseApplicationFontSize(float size) {
        UIDefaults defaults = UIManager.getLookAndFeelDefaults();
        for (Object key : defaults.keySet()) {
            Object value = defaults.get(key);
            if (value instanceof Font font) {
                defaults.put(key, font.deriveFont(size));
            }
        }
    }
}
