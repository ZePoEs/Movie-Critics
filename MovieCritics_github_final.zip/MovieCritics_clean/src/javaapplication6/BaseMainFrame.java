package javaapplication6;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

abstract class BaseMainFrame extends JFrame {
    protected final DatabaseManager database;
    protected final UserAccount currentUser;
    protected final boolean includeRestrictedMovies;
    protected final List<Movie> movieRows = new ArrayList<>();
    protected final JTable movieTable = new JTable();
    protected final DefaultTableModel movieModel = new ReadOnlyTableModel();
    protected final JTextField searchField = new JTextField(18);
    protected final JComboBox<String> genreCombo = new JComboBox<>();
    protected final JComboBox<String> directorCombo = new JComboBox<>();
    protected final JTextField yearField = new JTextField(6);
    protected final JTextArea detailsArea = new JTextArea();
    protected final JScrollPane detailsScrollPane = new JScrollPane(detailsArea);
    protected final JTable ratingsTable = new JTable();
    protected final DefaultTableModel ratingsModel = new ReadOnlyTableModel();

    BaseMainFrame(DatabaseManager database, UserAccount currentUser, boolean includeRestrictedMovies, String frameName) {
        super("MovieCritics - " + frameName + " - " + currentUser.username);
        this.database = database;
        this.currentUser = currentUser;
        this.includeRestrictedMovies = includeRestrictedMovies;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1260, 800);
        setLocationRelativeTo(null);
    }

    protected JPanel createHeader(String label) {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBorder(BorderFactory.createEmptyBorder(12, 14, 10, 14));
        JLabel title = new JLabel(label);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        JLabel userLabel = new JLabel(currentUser.username + " (" + currentUser.roleName() + ")");
        JButton logout = new JButton("Logout");
        logout.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame(database).setVisible(true));
        });
        JPanel right = new JPanel(new BorderLayout(10, 0));
        right.add(userLabel, BorderLayout.CENTER);
        right.add(logout, BorderLayout.EAST);
        header.add(title, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    protected JPanel createMovieBrowserPanel(Component actionPanel) {
        movieModel.setColumnIdentifiers(movieTableColumns());
        movieTable.setModel(movieModel);
        movieTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        movieTable.setAutoCreateRowSorter(true);
        movieTable.setRowHeight(30);
        configureMovieTableColumns();
        movieTable.setDefaultRenderer(Object.class, new MovieRestrictionRenderer(restrictedColumnIndex()));
        movieTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                Movie movie = selectedMovie();
                if (movie != null) {
                    displayMovieDetails(movie);
                    onMovieSelected(movie);
                }
            }
        });

        JPanel filters = new JPanel(new GridBagLayout());
        filters.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 4, 3, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        filters.add(new JLabel("Search"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        filters.add(searchField, gbc);
        gbc.weightx = 0;
        gbc.gridx = 2;
        filters.add(new JLabel("Genre"), gbc);
        gbc.gridx = 3;
        filters.add(genreCombo, gbc);
        gbc.gridx = 4;
        filters.add(new JLabel("Director"), gbc);
        gbc.gridx = 5;
        filters.add(directorCombo, gbc);
        gbc.gridx = 6;
        filters.add(new JLabel("Year"), gbc);
        gbc.gridx = 7;
        filters.add(yearField, gbc);
        JButton apply = new JButton("Apply");
        apply.addActionListener(e -> reloadMovies());
        gbc.gridx = 8;
        filters.add(apply, gbc);
        JButton clear = new JButton("Clear");
        clear.addActionListener(e -> clearFilters());
        gbc.gridx = 9;
        filters.add(clear, gbc);

        detailsArea.setEditable(false);
        detailsArea.setLineWrap(true);
        detailsArea.setWrapStyleWord(true);
        detailsArea.setRows(10);
        detailsArea.setFont(detailsArea.getFont().deriveFont(17f));
        detailsArea.setFocusable(false);
        detailsArea.setAutoscrolls(false);
        detailsArea.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        detailsScrollPane.setPreferredSize(new Dimension(430, 300));
        detailsScrollPane.getVerticalScrollBar().setUnitIncrement(18);

        ratingsModel.setColumnIdentifiers(new Object[]{"User", "Role", "Watched", "Rating", "Comment", "Status", "Date"});
        ratingsTable.setModel(ratingsModel);
        ratingsTable.setFillsViewportHeight(true);
        ratingsTable.setRowHeight(28);
        ratingsTable.setAutoCreateRowSorter(true);
        ratingsTable.getColumnModel().getColumn(0).setPreferredWidth(110);
        ratingsTable.getColumnModel().getColumn(1).setPreferredWidth(80);
        ratingsTable.getColumnModel().getColumn(2).setPreferredWidth(75);
        ratingsTable.getColumnModel().getColumn(3).setPreferredWidth(65);
        ratingsTable.getColumnModel().getColumn(4).setPreferredWidth(320);
        ratingsTable.getColumnModel().getColumn(5).setPreferredWidth(125);
        ratingsTable.getColumnModel().getColumn(6).setPreferredWidth(95);

        JPanel right = new JPanel(new BorderLayout(8, 8));
        right.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 0));
        JLabel detailLabel = new JLabel("Movie details and family ratings");
        detailLabel.setFont(detailLabel.getFont().deriveFont(Font.BOLD, 16f));
        right.add(detailLabel, BorderLayout.NORTH);

        JPanel rightCenter = new JPanel(new BorderLayout(8, 8));
        rightCenter.add(detailsScrollPane, BorderLayout.NORTH);
        rightCenter.add(new JScrollPane(ratingsTable), BorderLayout.CENTER);
        if (actionPanel != null) {
            rightCenter.add(actionPanel, BorderLayout.SOUTH);
        }
        right.add(rightCenter, BorderLayout.CENTER);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(movieTable), right);
        split.setResizeWeight(0.58);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(filters, BorderLayout.NORTH);
        panel.add(split, BorderLayout.CENTER);
        reloadFilters();
        reloadMovies();
        return panel;
    }

    protected void reloadFilters() {
        try {
            String selectedGenre = (String) genreCombo.getSelectedItem();
            String selectedDirector = (String) directorCombo.getSelectedItem();
            genreCombo.removeAllItems();
            for (String genre : database.listGenres(includeRestrictedMovies)) {
                genreCombo.addItem(genre);
            }
            directorCombo.removeAllItems();
            for (String director : database.listDirectors(includeRestrictedMovies)) {
                directorCombo.addItem(director);
            }
            if (selectedGenre != null) {
                genreCombo.setSelectedItem(selectedGenre);
            }
            if (selectedDirector != null) {
                directorCombo.setSelectedItem(selectedDirector);
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    protected void reloadMovies() {
        try {
            Movie previouslySelected = selectedMovie();
            int selectedMovieId = previouslySelected == null ? 0 : previouslySelected.id;
            movieRows.clear();
            movieRows.addAll(database.searchMovies(
                    searchField.getText(),
                    (String) genreCombo.getSelectedItem(),
                    (String) directorCombo.getSelectedItem(),
                    yearField.getText(),
                    includeRestrictedMovies
            ));
            movieModel.setRowCount(0);
            for (Movie movie : movieRows) {
                movieModel.addRow(movieRowValues(movie));
            }
            if (!movieRows.isEmpty()) {
                int rowToSelect = 0;
                for (int i = 0; i < movieRows.size(); i++) {
                    if (movieRows.get(i).id == selectedMovieId) {
                        rowToSelect = i;
                        break;
                    }
                }
                int viewRow = movieTable.convertRowIndexToView(rowToSelect);
                movieTable.setRowSelectionInterval(viewRow, viewRow);
            } else {
                detailsArea.setText("No movies found.");
                resetDetailsScroll();
                ratingsModel.setRowCount(0);
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    protected void clearFilters() {
        searchField.setText("");
        yearField.setText("");
        genreCombo.setSelectedIndex(0);
        directorCombo.setSelectedIndex(0);
        reloadMovies();
    }

    protected Movie selectedMovie() {
        int viewRow = movieTable.getSelectedRow();
        if (viewRow < 0) {
            return null;
        }
        int modelRow = movieTable.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= movieRows.size()) {
            return null;
        }
        return movieRows.get(modelRow);
    }

    protected void displayMovieDetails(Movie movie) {
        StringBuilder text = new StringBuilder();
        text.append(movie.title).append("\n");
        text.append("Release date: ").append(safe(movie.releaseDate)).append("\n");
        text.append("Language: ").append(safe(movie.language)).append("\n");
        text.append("Country: ").append(safe(movie.country)).append("\n");
        text.append("Genre: ").append(safe(movie.genre)).append("\n");
        text.append("Director: ").append(safe(movie.directorName)).append("\n");
        text.append("Leading actor/actress: ").append(safe(movie.leadingActorName)).append("\n");
        text.append("Supporting actor/actress: ").append(safe(movie.supportingActorName)).append("\n");
        text.append("Library rating: ").append(movie.rating == null ? "-" : movie.rating).append("/5\n");
        text.append("Parental restriction: ").append(movie.parentalRestriction ? "Yes" : "No").append("\n\n");
        text.append("About\n").append(safe(movie.about)).append("\n\n");
        text.append("Library comments\n").append(safe(movie.comments));
        detailsArea.setText(text.toString());
        resetDetailsScroll();
        reloadRatings(movie.id);
    }

    private void resetDetailsScroll() {
        detailsArea.setCaretPosition(0);
        SwingUtilities.invokeLater(() -> {
            detailsArea.setCaretPosition(0);
            detailsScrollPane.getVerticalScrollBar().setValue(0);
            detailsScrollPane.getHorizontalScrollBar().setValue(0);
        });
    }

    protected void reloadRatings(int movieId) {
        try {
            ratingsModel.setRowCount(0);
            for (RatingRecord record : database.ratingsForMovie(movieId, currentUser.id, currentUser.isParent())) {
                ratingsModel.addRow(new Object[]{
                    record.username,
                    record.role,
                    record.watched ? "Yes" : "No",
                    record.rating == null ? "" : record.rating,
                    safe(record.comment),
                    record.commentApproved ? "Public" : "Pending approval",
                    safe(record.date)
                });
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    protected void onMovieSelected(Movie movie) {
    }

    protected Object[] movieTableColumns() {
        return new Object[]{"ID", "Title", "Year", "Genre", "Director", "Rating", "Restricted"};
    }

    protected Object[] movieRowValues(Movie movie) throws SQLException {
        return new Object[]{
            movie.id,
            movie.title,
            movieYear(movie),
            safe(movie.genre),
            safe(movie.directorName),
            movie.rating == null ? "" : movie.rating,
            movie.parentalRestriction ? "Yes" : "No"
        };
    }

    protected void configureMovieTableColumns() {
        movieTable.getColumnModel().getColumn(0).setMaxWidth(48);
        movieTable.getColumnModel().getColumn(2).setMaxWidth(70);
        movieTable.getColumnModel().getColumn(5).setMaxWidth(70);
        movieTable.getColumnModel().getColumn(restrictedColumnIndex()).setMaxWidth(90);
    }

    protected int restrictedColumnIndex() {
        return 6;
    }

    protected String movieYear(Movie movie) {
        return movie.releaseDate == null ? "" : movie.releaseDate.substring(0, Math.min(4, movie.releaseDate.length()));
    }

    protected void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "MovieCritics error", JOptionPane.ERROR_MESSAGE);
    }

    protected static String safe(String text) {
        return text == null ? "" : text;
    }

    private static final class MovieRestrictionRenderer extends DefaultTableCellRenderer {
        private final int restrictedColumn;

        MovieRestrictionRenderer(int restrictedColumn) {
            this.restrictedColumn = restrictedColumn;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (!isSelected) {
                String restricted = String.valueOf(table.getValueAt(row, restrictedColumn));
                c.setBackground("Yes".equals(restricted) ? UiTheme.RESTRICTED_ROW : UiTheme.FIELD);
                c.setForeground(UiTheme.TEXT);
            }
            return c;
        }
    }
}
