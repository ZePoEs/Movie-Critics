package javaapplication6;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

final class Type2MainFrame extends BaseMainFrame {
    private JTabbedPane tabs;
    private final JCheckBox watchedBox = new JCheckBox("Watched");
    private final JSpinner ratingSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 5, 1));
    private final JTextArea commentArea = new JTextArea(3, 22);
    private final JLabel personalStatusLabel = new JLabel("My status: Select a movie");
    private final JTable watchedTable = new JTable();
    private final DefaultTableModel watchedModel = new ReadOnlyTableModel();
    private final List<PersonalMovieRecord> watchedRows = new ArrayList<>();
    private final JTable watchlistTable = new JTable();
    private final DefaultTableModel watchlistModel = new ReadOnlyTableModel();
    private final List<WatchlistRecord> watchlistRows = new ArrayList<>();
    private final JTable familyCommentsTable = new JTable();
    private final DefaultTableModel familyCommentsModel = new ReadOnlyTableModel();
    private final List<FamilyCommentRecord> familyCommentRows = new ArrayList<>();
    private final JLabel visibleMoviesValue = new JLabel("-");
    private final JLabel watchedMoviesValue = new JLabel("-");
    private final JLabel remainingMoviesValue = new JLabel("-");
    private final JLabel progressPercentValue = new JLabel("-");
    private final JProgressBar progressBar = new JProgressBar(0, 100);
    private final JTable progressTable = new JTable();
    private final DefaultTableModel progressModel = new ReadOnlyTableModel();

    Type2MainFrame(DatabaseManager database, UserAccount currentUser) {
        super(database, currentUser, false, "Kid");
        buildUi();
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout());
        root.add(createHeader("Kid"), BorderLayout.NORTH);
        tabs = new JTabbedPane();
        tabs.addTab("Kid Home", createChildHomePanel());
        tabs.addTab("Browse / Rate", createMovieBrowserPanel(createActivityPanel()));
        tabs.addTab("My Watched", createWatchedPanel());
        tabs.addTab("Watchlist", createWatchlistPanel());
        tabs.addTab("Progress", createProgressPanel());
        tabs.addTab("Family Comments", createFamilyCommentsPanel());
        root.add(tabs, BorderLayout.CENTER);
        setContentPane(root);
        UiTheme.apply(root);
        refreshWatchedMovies();
        refreshWatchlist();
        refreshProgress();
        refreshFamilyComments();
    }

    private JPanel createChildHomePanel() {
        JPanel panel = new JPanel(new BorderLayout(18, 18));
        panel.setBorder(BorderFactory.createEmptyBorder(34, 46, 46, 46));

        JLabel title = new JLabel("Child / Member Panel", JLabel.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 28f));
        JLabel loggedIn = new JLabel("Logged in as: " + currentUser.username + " (" + currentUser.roleName() + ")", JLabel.CENTER);

        JPanel header = new JPanel(new BorderLayout(0, 14));
        header.add(title, BorderLayout.NORTH);
        header.add(loggedIn, BorderLayout.CENTER);

        JPanel actions = new JPanel(new GridLayout(5, 2, 18, 18));
        actions.add(menuButton("Log Watched Movies", () -> tabs.setSelectedIndex(1)));
        actions.add(menuButton("My Watched Movies", () -> tabs.setSelectedIndex(2)));
        actions.add(menuButton("Rate Movies", () -> tabs.setSelectedIndex(1)));
        actions.add(menuButton("View Family Comments", () -> tabs.setSelectedIndex(5)));
        actions.add(menuButton("Create Personal Watchlist", () -> tabs.setSelectedIndex(3)));
        actions.add(menuButton("Track Progress", () -> tabs.setSelectedIndex(4)));
        actions.add(menuButton("Browse Movies", () -> tabs.setSelectedIndex(1)));
        actions.add(menuButton("View Family Ratings", () -> tabs.setSelectedIndex(1)));
        actions.add(menuButton("Logout", this::logout));
        actions.add(new JLabel(""));

        panel.add(header, BorderLayout.NORTH);
        panel.add(actions, BorderLayout.CENTER);
        return panel;
    }

    private JButton menuButton(String text, Runnable action) {
        JButton button = new JButton(text);
        button.setFont(button.getFont().deriveFont(Font.BOLD, 16f));
        button.addActionListener(e -> action.run());
        return button;
    }

    private void logout() {
        dispose();
        javax.swing.SwingUtilities.invokeLater(() -> new LoginFrame(database).setVisible(true));
    }

    private JPanel createActivityPanel() {
        commentArea.setLineWrap(true);
        commentArea.setWrapStyleWord(true);
        commentArea.setRows(3);
        commentArea.setColumns(28);
        commentArea.setFont(commentArea.getFont().deriveFont(17f));
        personalStatusLabel.setFont(personalStatusLabel.getFont().deriveFont(Font.BOLD, 15f));
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("My movie activity"));

        JPanel controls = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2, 6, 2, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        controls.add(watchedBox, gbc);
        gbc.gridx = 1;
        controls.add(new JLabel("Rating 1-5"), gbc);
        gbc.gridx = 2;
        controls.add(ratingSpinner, gbc);

        JPanel commentPanel = new JPanel(new BorderLayout(4, 4));
        commentPanel.add(new JLabel("My comment"), BorderLayout.NORTH);
        commentPanel.add(new JScrollPane(commentArea), BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout(6, 6));
        center.add(controls, BorderLayout.NORTH);
        center.add(commentPanel, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new GridLayout(1, 3, 8, 0));
        JButton save = new JButton("Save Activity");
        save.addActionListener(e -> saveActivity());
        JButton addWatchlist = new JButton("Add Watchlist");
        addWatchlist.addActionListener(e -> addSelectedToWatchlist());
        JButton removeWatchlist = new JButton("Remove Watchlist");
        removeWatchlist.addActionListener(e -> removeSelectedFromWatchlist());
        buttons.add(save);
        buttons.add(addWatchlist);
        buttons.add(removeWatchlist);

        panel.add(personalStatusLabel, BorderLayout.NORTH);
        panel.add(center, BorderLayout.CENTER);
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createWatchedPanel() {
        watchedModel.setColumnIdentifiers(new Object[]{"Movie ID", "Title", "Genre", "My Rating", "Watched Date"});
        watchedTable.setModel(watchedModel);
        watchedTable.setRowHeight(28);
        watchedTable.setAutoCreateRowSorter(true);
        watchedTable.getColumnModel().getColumn(0).setMaxWidth(80);
        watchedTable.getColumnModel().getColumn(3).setMaxWidth(90);

        JPanel buttons = new JPanel();
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> refreshWatchedMovies());
        JButton open = new JButton("Open in Browse");
        open.addActionListener(e -> openSelectedWatchedMovie());
        JButton addWatchlist = new JButton("Add to Watchlist");
        addWatchlist.addActionListener(e -> addSelectedWatchedToWatchlist());
        JButton markNotWatched = new JButton("Mark Not Watched");
        markNotWatched.addActionListener(e -> markSelectedNotWatched());
        buttons.add(refresh);
        buttons.add(open);
        buttons.add(addWatchlist);
        buttons.add(markNotWatched);

        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        panel.add(new JScrollPane(watchedTable), BorderLayout.CENTER);
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createWatchlistPanel() {
        watchlistModel.setColumnIdentifiers(new Object[]{"Movie ID", "Title", "Genre", "Added Date"});
        watchlistTable.setModel(watchlistModel);
        watchlistTable.setRowHeight(28);
        watchlistTable.setAutoCreateRowSorter(true);
        watchlistTable.getColumnModel().getColumn(0).setMaxWidth(80);

        JPanel buttons = new JPanel();
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> refreshWatchlist());
        JButton remove = new JButton("Remove Selected");
        remove.addActionListener(e -> removeSelectedWatchlistRow());
        buttons.add(refresh);
        buttons.add(remove);

        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        panel.add(new JScrollPane(watchlistTable), BorderLayout.CENTER);
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createProgressPanel() {
        progressModel.setColumnIdentifiers(new Object[]{"Child", "Watched Movies", "Visible Movies", "Progress"});
        progressTable.setModel(progressModel);
        progressTable.setRowHeight(30);
        progressTable.setAutoCreateRowSorter(true);
        progressTable.setFillsViewportHeight(true);
        progressBar.setStringPainted(true);

        JButton refresh = new JButton("Refresh Progress");
        refresh.addActionListener(e -> refreshProgress());

        JPanel summary = new JPanel(new GridLayout(1, 4, 10, 10));
        summary.add(metricPanel("Visible movies", visibleMoviesValue));
        summary.add(metricPanel("Watched by me", watchedMoviesValue));
        summary.add(metricPanel("Remaining", remainingMoviesValue));
        summary.add(metricPanel("My progress", progressPercentValue));

        JPanel top = new JPanel(new BorderLayout(8, 8));
        JLabel title = new JLabel("My Progress");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        top.add(title, BorderLayout.NORTH);
        top.add(summary, BorderLayout.CENTER);
        top.add(progressBar, BorderLayout.SOUTH);

        JPanel center = new JPanel(new BorderLayout(8, 8));
        JLabel comparison = new JLabel("Sibling comparison");
        comparison.setFont(comparison.getFont().deriveFont(Font.BOLD, 16f));
        center.add(comparison, BorderLayout.NORTH);
        center.add(new JScrollPane(progressTable), BorderLayout.CENTER);

        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        panel.add(top, BorderLayout.NORTH);
        panel.add(center, BorderLayout.CENTER);
        panel.add(refresh, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createFamilyCommentsPanel() {
        familyCommentsModel.setColumnIdentifiers(new Object[]{"Movie ID", "Movie", "User", "Role", "Rating", "Comment", "Status", "Date"});
        familyCommentsTable.setModel(familyCommentsModel);
        familyCommentsTable.setRowHeight(30);
        familyCommentsTable.setAutoCreateRowSorter(true);
        familyCommentsTable.setFillsViewportHeight(true);
        familyCommentsTable.getColumnModel().getColumn(0).setMaxWidth(70);
        familyCommentsTable.getColumnModel().getColumn(1).setPreferredWidth(170);
        familyCommentsTable.getColumnModel().getColumn(2).setPreferredWidth(110);
        familyCommentsTable.getColumnModel().getColumn(5).setPreferredWidth(380);
        familyCommentsTable.getColumnModel().getColumn(6).setPreferredWidth(120);

        JPanel buttons = new JPanel();
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> refreshFamilyComments());
        JButton open = new JButton("Open Movie");
        open.addActionListener(e -> openSelectedCommentMovie());
        buttons.add(refresh);
        buttons.add(open);

        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        panel.add(new JScrollPane(familyCommentsTable), BorderLayout.CENTER);
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    @Override
    protected Object[] movieTableColumns() {
        return new Object[]{"ID", "Title", "Year", "Genre", "Director", "Rating", "My Status", "Watchlist", "Restricted"};
    }

    @Override
    protected Object[] movieRowValues(Movie movie) throws SQLException {
        ActivityRecord record = database.activityForUserMovie(currentUser.id, movie.id);
        boolean watched = record != null && record.watched;
        boolean inWatchlist = database.isInWatchlist(currentUser.id, movie.id);
        return new Object[]{
            movie.id,
            movie.title,
            movieYear(movie),
            safe(movie.genre),
            safe(movie.directorName),
            movie.rating == null ? "" : movie.rating,
            watched ? "Watched" : "Not watched",
            inWatchlist ? "Yes" : "No",
            movie.parentalRestriction ? "Yes" : "No"
        };
    }

    @Override
    protected void configureMovieTableColumns() {
        movieTable.getColumnModel().getColumn(0).setMaxWidth(48);
        movieTable.getColumnModel().getColumn(2).setMaxWidth(70);
        movieTable.getColumnModel().getColumn(5).setMaxWidth(70);
        movieTable.getColumnModel().getColumn(6).setPreferredWidth(105);
        movieTable.getColumnModel().getColumn(7).setMaxWidth(95);
        movieTable.getColumnModel().getColumn(8).setMaxWidth(90);
    }

    @Override
    protected int restrictedColumnIndex() {
        return 8;
    }

    @Override
    protected void onMovieSelected(Movie movie) {
        try {
            ActivityRecord record = database.activityForUserMovie(currentUser.id, movie.id);
            if (record == null) {
                watchedBox.setSelected(false);
                ratingSpinner.setValue(3);
                commentArea.setText("");
            } else {
                watchedBox.setSelected(record.watched);
                ratingSpinner.setValue(record.rating == null ? 3 : record.rating);
                commentArea.setText(safe(record.comment));
            }
            updatePersonalStatus(movie, record);
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void saveActivity() {
        Movie movie = selectedMovie();
        if (movie == null) {
            return;
        }
        try {
            database.saveActivity(
                    currentUser.id,
                    movie.id,
                    watchedBox.isSelected(),
                    (Integer) ratingSpinner.getValue(),
                    commentArea.getText()
            );
            ActivityRecord saved = database.activityForUserMovie(currentUser.id, movie.id);
            reloadMovies();
            reloadRatings(movie.id);
            refreshWatchedMovies();
            refreshProgress();
            refreshFamilyComments();
            updateCurrentPersonalStatus();
            if (saved != null && !saved.commentApproved && commentArea.getText() != null && !commentArea.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Your rating was saved. Your comment is waiting for parent approval.");
            } else {
                JOptionPane.showMessageDialog(this, "Your movie activity was saved.");
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void addSelectedToWatchlist() {
        Movie movie = selectedMovie();
        if (movie == null) {
            return;
        }
        try {
            database.addToWatchlist(currentUser.id, movie.id);
            refreshWatchlist();
            updateCurrentPersonalStatus();
            JOptionPane.showMessageDialog(this, "Movie added to your watchlist.");
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void removeSelectedFromWatchlist() {
        Movie movie = selectedMovie();
        if (movie == null) {
            return;
        }
        try {
            database.removeFromWatchlist(currentUser.id, movie.id);
            refreshWatchlist();
            updateCurrentPersonalStatus();
            JOptionPane.showMessageDialog(this, "Movie removed from your watchlist if it was there.");
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void refreshWatchedMovies() {
        try {
            watchedRows.clear();
            watchedRows.addAll(database.watchedMoviesForUser(currentUser.id));
            watchedModel.setRowCount(0);
            for (PersonalMovieRecord row : watchedRows) {
                watchedModel.addRow(new Object[]{
                    row.movieId,
                    row.title,
                    row.genre,
                    row.rating == null ? "" : row.rating,
                    row.date
                });
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void refreshWatchlist() {
        try {
            watchlistRows.clear();
            watchlistRows.addAll(database.watchlistForUser(currentUser.id));
            watchlistModel.setRowCount(0);
            for (WatchlistRecord row : watchlistRows) {
                watchlistModel.addRow(new Object[]{row.movieId, row.title, row.genre, row.addedDate});
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void removeSelectedWatchlistRow() {
        int view = watchlistTable.getSelectedRow();
        if (view < 0) {
            return;
        }
        int model = watchlistTable.convertRowIndexToModel(view);
        WatchlistRecord record = watchlistRows.get(model);
        try {
            database.removeFromWatchlist(currentUser.id, record.movieId);
            refreshWatchlist();
            updateCurrentPersonalStatus();
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void openSelectedWatchedMovie() {
        PersonalMovieRecord record = selectedWatchedRecord();
        if (record == null) {
            return;
        }
        openMovieInBrowser(record.movieId);
    }

    private void addSelectedWatchedToWatchlist() {
        PersonalMovieRecord record = selectedWatchedRecord();
        if (record == null) {
            return;
        }
        try {
            database.addToWatchlist(currentUser.id, record.movieId);
            refreshWatchlist();
            updateCurrentPersonalStatus();
            JOptionPane.showMessageDialog(this, "Movie added to your watchlist.");
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void markSelectedNotWatched() {
        PersonalMovieRecord record = selectedWatchedRecord();
        if (record == null) {
            return;
        }
        try {
            database.setWatchedForUserMovie(currentUser.id, record.movieId, false);
            refreshWatchedMovies();
            reloadMovies();
            reloadRatings(record.movieId);
            refreshProgress();
            updateCurrentPersonalStatus();
            JOptionPane.showMessageDialog(this, "Movie moved out of your watched list.");
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private PersonalMovieRecord selectedWatchedRecord() {
        int view = watchedTable.getSelectedRow();
        if (view < 0) {
            return null;
        }
        int model = watchedTable.convertRowIndexToModel(view);
        if (model < 0 || model >= watchedRows.size()) {
            return null;
        }
        return watchedRows.get(model);
    }

    private void openMovieInBrowser(int movieId) {
        tabs.setSelectedIndex(1);
        searchField.setText("");
        yearField.setText("");
        genreCombo.setSelectedIndex(0);
        directorCombo.setSelectedIndex(0);
        reloadMovies();
        for (int i = 0; i < movieRows.size(); i++) {
            if (movieRows.get(i).id == movieId) {
                int view = movieTable.convertRowIndexToView(i);
                movieTable.setRowSelectionInterval(view, view);
                movieTable.scrollRectToVisible(movieTable.getCellRect(view, 0, true));
                break;
            }
        }
    }

    private void updateCurrentPersonalStatus() {
        Movie movie = selectedMovie();
        if (movie == null) {
            personalStatusLabel.setText("My status: Select a movie");
            return;
        }
        try {
            updatePersonalStatus(movie, database.activityForUserMovie(currentUser.id, movie.id));
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void updatePersonalStatus(Movie movie, ActivityRecord record) throws SQLException {
        boolean watched = record != null && record.watched;
        boolean inWatchlist = database.isInWatchlist(currentUser.id, movie.id);
        String rating = record == null || record.rating == null ? "-" : String.valueOf(record.rating);
        personalStatusLabel.setText("My status: " + (watched ? "Watched" : "Not watched")
                + " | My rating: " + rating
                + " | Watchlist: " + (inWatchlist ? "Yes" : "No"));
    }

    private void refreshProgress() {
        try {
            PersonalProgressSummary summary = database.personalProgressSummary(currentUser);
            visibleMoviesValue.setText(String.valueOf(summary.visibleMovies));
            watchedMoviesValue.setText(String.valueOf(summary.watchedMovies));
            remainingMoviesValue.setText(String.valueOf(summary.remainingMovies));
            progressPercentValue.setText(summary.progressPercent);
            progressBar.setValue(summary.progressValue);
            progressBar.setString(summary.progressPercent);

            progressModel.setRowCount(0);
            for (Object[] row : database.childProgressAnalyticsRows()) {
                Object[] display = row.clone();
                if (String.valueOf(display[0]).equals(currentUser.username)) {
                    display[0] = display[0] + " (me)";
                }
                progressModel.addRow(display);
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void refreshFamilyComments() {
        try {
            familyCommentRows.clear();
            familyCommentRows.addAll(database.familyCommentsForViewer(currentUser.id, currentUser.isParent(), false));
            familyCommentsModel.setRowCount(0);
            for (FamilyCommentRecord row : familyCommentRows) {
                familyCommentsModel.addRow(new Object[]{
                    row.movieId,
                    row.movieTitle,
                    row.username,
                    row.role,
                    row.rating == null ? "" : row.rating,
                    safe(row.comment),
                    row.status,
                    safe(row.date)
                });
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void openSelectedCommentMovie() {
        int view = familyCommentsTable.getSelectedRow();
        if (view < 0) {
            return;
        }
        int model = familyCommentsTable.convertRowIndexToModel(view);
        if (model < 0 || model >= familyCommentRows.size()) {
            return;
        }
        openMovieInBrowser(familyCommentRows.get(model).movieId);
    }

    private JPanel metricPanel(String title, JLabel valueLabel) {
        JPanel panel = new JPanel(new BorderLayout(4, 4));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UiTheme.BORDER),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(UiTheme.MUTED);
        valueLabel.setFont(valueLabel.getFont().deriveFont(Font.BOLD, 18f));
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(valueLabel, BorderLayout.CENTER);
        return panel;
    }
}
