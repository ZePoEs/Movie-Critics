package javaapplication6;

import javax.swing.table.DefaultTableModel;

final class ReadOnlyTableModel extends DefaultTableModel {
    @Override
    public boolean isCellEditable(int row, int column) {
        return false;
    }
}

final class UserAccount {
    int id;
    String username;
    String password;
    int userType;
    String email;

    UserAccount(int id, String username, String password, int userType, String email) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.userType = userType;
        this.email = email;
    }

    boolean isParent() {
        return userType == 1;
    }

    String roleName() {
        return isParent() ? "Parent/Adult" : "Child";
    }
}

final class PersonItem {
    int id;
    String firstName;
    String lastName;
    String dateOfBirth;
    String nationality;

    PersonItem(int id, String firstName, String lastName, String dateOfBirth, String nationality) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.nationality = nationality;
    }

    String fullName() {
        if (id == 0) {
            return "(none)";
        }
        return firstName + " " + lastName;
    }

    @Override
    public String toString() {
        return fullName();
    }
}

final class Movie {
    int id;
    String title;
    String releaseDate;
    String language;
    String country;
    String genre;
    int directorId;
    String directorName;
    boolean watchedOrNot;
    int leadingActorId;
    String leadingActorName;
    int supportingActorId;
    String supportingActorName;
    String about;
    Integer rating;
    String comments;
    String poster;
    boolean parentalRestriction;
}

final class RatingRecord {
    int userId;
    String username;
    String role;
    boolean watched;
    Integer rating;
    String comment;
    String date;
    boolean commentApproved;
}

final class ActivityRecord {
    int activityId;
    int userId;
    int movieId;
    String username;
    String movieTitle;
    boolean watched;
    Integer rating;
    String comment;
    String date;
    boolean commentApproved;
}

final class WatchlistRecord {
    int watchlistId;
    int movieId;
    String title;
    String genre;
    String addedDate;
}

final class PersonalMovieRecord {
    int movieId;
    String title;
    String genre;
    Integer rating;
    String date;
}

final class PersonalProgressSummary {
    int visibleMovies;
    int watchedMovies;
    int remainingMovies;
    int progressValue;
    String progressPercent;
}

final class FamilyCommentRecord {
    int movieId;
    String movieTitle;
    String username;
    String role;
    Integer rating;
    String comment;
    String status;
    String date;
}

final class AnalyticsSummary {
    int movieCount;
    int watchedMovieCount;
    int restrictedMovieCount;
    int parentCount;
    int childCount;
    int activityCount;
    int watchlistCount;
    int pendingCommentCount;
    String averageFamilyRating;
}
