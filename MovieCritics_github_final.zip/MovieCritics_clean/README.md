# MovieCritics

A Java Swing desktop application for browsing, reviewing, and managing movies. Users can log in, search movies, add them to a watchlist, and write reviews.

## Features

- User authentication (Login / Register)
- Movie browsing and search
- Watchlist management
- Movie reviews and ratings
- SQLite database (embedded, no server required)

## Requirements

- Java 21+
- SQLite JDBC driver (`sqlite-jdbc-3.51.3.0.jar`)

## Project Structure

```
src/
└── javaapplication6/
    ├── JavaApplication6.java   # Entry point
    ├── LoginFrame.java         # Login / register UI
    ├── BaseMainFrame.java      # Shared UI base
    ├── Type1MainFrame.java     # Main UI (Type 1 user)
    ├── Type2MainFrame.java     # Main UI (Type 2 user)
    ├── DatabaseManager.java    # All database operations
    ├── Models.java             # Data model classes
    └── UiTheme.java            # UI theming / fonts
```

## How to Run

1. Add `sqlite-jdbc-3.51.3.0.jar` to your project's classpath (download from [GitHub](https://github.com/xerial/sqlite-jdbc/releases)).
2. Compile the source files.
3. Run `javaapplication6.JavaApplication6`.

## Dependencies

| Library | Version | Purpose |
|---------|---------|---------|
| sqlite-jdbc | 3.51.3.0 | SQLite database access |
